<?php 
function ethershop_save_update_vendor_product( $post_id, $post, $update ){
if ($post->post_type != 'product') {
	return;
}
	
if (($post->post_status == 'auto-draft') || ($post->post_status == 'draft')) {
	return;
}
global $current_user, $wpdb, $remotedb, $vendor_id;
$email = $current_user->user_email;
$vendor_id = $remotedb->get_var("SELECT ID FROM ".$remotedb->prefix."users WHERE user_email ='".$email."'"); 
$POST      = array_map( 'stripslashes_deep', $_POST);

$term_id = $POST['tax_input']['product_cat'];
$prod_tag = $POST['tax_input']['product_tag'];
$_thumbnail_id = $POST['_thumbnail_id'];

$mysqldate = date("Y-m-d H:i:s");
if(isset($_POST['save']) && ($_POST['save'] == 'Update')){
$remote_post_id = $wpdb->get_var("SELECT post_content_filtered FROM {$wpdb->posts} WHERE post_status IN ('pending','publish') AND post_content_filtered != '' AND ID =".$post_id);
$remotedb->update($remotedb->prefix.'posts', array('post_content' => $post->post_content, 'post_excerpt' => $post->post_excerpt, 'post_title' => $post->post_title, 'post_name' => $post->post_name, 'post_status' => $post->post_status), array('ID' => intval($remote_post_id)));
$remotedb->delete($remotedb->prefix.'term_relationships', array( 'object_id' => $remote_post_id));
if(!empty($term_id)){
  remote_product_taxonomy($term_id, $remote_post_id, 'product_cat');
}
if(!empty($prod_tag)){
  remote_product_taxonomy($prod_tag, $remote_post_id, 'product_tag');
}
remote_product_update_meta_data($remote_post_id, $POST);
  $to = 'papelbd@gmail.com';
  $subject = 'The custom post subject Update';
  $body = "Post title , remote_post_id :". $remote_post_id;
  $headers = array('Content-Type:text/html; charset=UTF-8');
  wp_mail($to, $subject, $body, $headers);
}elseif(isset($_POST['publish']) && ($_POST['publish'] == 'Publish')){
$check_post = $wpdb->get_row("SELECT * FROM {$wpdb->posts} WHERE post_status IN ('pending','publish') AND post_content_filtered != '' AND ID =".$post_id, ARRAY_A); 
 if(!empty($check_post['ID'])){
   return;
 }
$remotedb->insert($remotedb->prefix.'posts', array('post_author' => $vendor_id, 'post_date' => $mysqldate, 'post_date_gmt' => $mysqldate, 'post_content' => $post->post_content, 'post_excerpt' => $post->post_excerpt, 'post_title' => $post->post_title, 'post_status' => 'publish', 'comment_status' => 'open', 'ping_status' => 'closed', 'post_name' => $post->post_name, 'post_content_filtered' => $post_id,'post_parent' => 0, 'guid' => '', 'post_type' => 'product', 'post_mime_type' => ''));
$post_parent = $remotedb->insert_id;
$remotedb->delete($remotedb->prefix.'term_relationships', array( 'object_id' => $post_parent));
$wpdb->update($wpdb->prefix.'posts', array('post_content_filtered' => $post_parent), array('ID' => $post_id));
if(!empty($_thumbnail_id)){
  remote_product_featured_image($post_parent, $vendor_id, $_thumbnail_id);
}
if(!empty($term_id)){
  remote_product_taxonomy($term_id, $post_parent, 'product_cat');
}
if(!empty($prod_tag)){
  remote_product_taxonomy($prod_tag, $post_parent, 'product_tag');
}
remote_product_meta_data($post_parent, $POST);
    $to = 'papelbd@gmail.com';
	$subject = 'The custom post subject Create';
	$body = "Post title " .print_r($prod_cat,1).print_r($prod_tag,1);
	$headers = array('Content-Type: text/html; charset=UTF-8');
	wp_mail($to, $subject, $body, $headers);
}

}//function
add_action( 'save_post', 'ethershop_save_update_vendor_product', 10, 3 );

add_action('wp_trash_post', 'ethershop_trash_post_product');
function ethershop_trash_post_product($post_id){
global $remotedb;
$remotedb->update($remotedb->prefix.'posts', array('post_status' => 'trash'), array('post_content_filtered' => $post_id));

  $to = 'papelbd@gmail.com';
  $subject = 'The custom post subject Deteted';
  $body = "Post ID " .$post_id;
  $headers = array('Content-Type: text/html; charset=UTF-8');
  wp_mail($to, $subject, $body, $headers);
}

function remote_product_taxonomy($term_id, $post_parent, $taxonomy_type){
global $wpdb, $remotedb;


foreach($term_id as $value):
  $terms = $wpdb->get_row("SELECT name, slug FROM ".$wpdb->prefix."terms WHERE term_id =".$value, ARRAY_A);
  if(!empty($terms['slug'])):
    $remotedb_terms = $remotedb->get_row("SELECT term_id, name, slug FROM ".$remotedb->prefix."terms WHERE slug = '".$terms['slug']."'", ARRAY_A);
   if(empty($remotedb_terms['term_id'])) {
    $remotedb->insert($remotedb->prefix.'terms', array('name' => $terms['name'], 'slug' => $terms['slug']));
	$remotedb_term_id = $remotedb->insert_id;
	$remotedb->insert($remotedb->prefix.'term_taxonomy', array('term_id' => $remotedb_term_id, 'taxonomy' => $taxonomy_type));
	$remotedb_term_taxonomy_id = $remotedb->insert_id;
	$remotedb->insert($remotedb->prefix.'term_relationships', array('object_id' => $post_parent, 'term_taxonomy_id' => $remotedb_term_taxonomy_id));
   }else{
	$remotedb_term_taxonomy_id = $remotedb->get_var("SELECT term_taxonomy_id FROM ".$remotedb->prefix."term_taxonomy WHERE taxonomy ='".$taxonomy_type."' AND term_id =".$remotedb_terms['term_id']);
    $remotedb->insert($remotedb->prefix.'term_relationships', array('object_id' => $post_parent, 'term_taxonomy_id' => $remotedb_term_taxonomy_id));
   }
  endif;
 endforeach;
}// function
function remote_product_featured_image($post_parent, $vendor_id, $_thumbnail_id){
global $wpdb, $remotedb;
$rupload_path =  "/home7/epicbran/public_html/moderntimbercraft/wp-content/uploads/2018/03/";
$rbaseurl =  "https://www.moderntimbercraft.com/wp-content/uploads/2018/03/";

$mysqldate = date("Y-m-d H:i:s");
$row = $wpdb->get_row("SELECT ID, post_name, guid FROM {$wpdb->posts} WHERE ID = {$_thumbnail_id} AND post_type = 'attachment'");
$fname = basename($row->guid);
$subdir_file = '2018/03/'.$fname;
$post_name = $row->post_name;
$rurl = $rbaseurl.$fname;
 if(is_writable($rupload_path)) {
    file_put_contents($rupload_path.$fname, file_get_contents($row->guid));
 }
$remotedb->insert($remotedb->prefix.'posts', array('post_author' => $vendor_id, 'post_date' => $mysqldate, 'post_date_gmt' => $mysqldate, 'post_content' => '', 'post_title' => $fname, 'post_status' => 'inherit', 'post_name' => $post_name, 'post_parent' => $post_parent, 'guid' => $rurl, 'post_type' => 'attachment', 'post_mime_type' => 'image/jpeg'));
$remote_thumbnail_id = $remotedb->insert_id;
$attachment_metadata = wp_get_attachment_metadata( $remote_thumbnail_id );
$attachment_metadata['file'] = $subdir_file;
$serialize_metadata = maybe_serialize($attachment_metadata);
$remotedb->insert($remotedb->prefix.'postmeta', array('post_id' => $remote_thumbnail_id, 'meta_key' => '_wp_attached_file', 'meta_value' => $subdir_file ));
$remotedb->insert($remotedb->prefix.'postmeta', array('post_id' => $remote_thumbnail_id, 'meta_key' => '_wp_attachment_metadata', 'meta_value' => $serialize_metadata ));
$remotedb->insert($remotedb->prefix.'postmeta', array('post_id' => $post_parent, 'meta_key' => '_thumbnail_id', 'meta_value' => $remote_thumbnail_id ));
}// function
function remote_product_meta_data($post_parent, $POST){
global $wpdb, $remotedb;
$product_type = $POST['product-type'];
$_regular_price = $POST['_regular_price'];
$_sale_price = $POST['_sale_price'];
$_sku = $POST['_sku'];
$_stock = $POST['_stock'];
$_original_stock = $POST['_original_stock']; 
$_stock_status = $POST['_stock_status'];
$remotedb->insert($remotedb->prefix.'postmeta', array('post_id' => $post_parent, 'meta_key' => '_sku', 'meta_value' => $_sku ));
$remotedb->insert($remotedb->prefix.'postmeta', array('post_id' => $post_parent, 'meta_key' => '_regular_price', 'meta_value' => $_regular_price ));
	if(empty($_sale_price) && ($_sale_price == '')){
	  $_price = $_regular_price;
	}else{
      $_price = $_sale_price;
	}
$remotedb->insert($remotedb->prefix.'postmeta', array('post_id' => $post_parent, 'meta_key' => '_sale_price', 'meta_value' => $_sale_price ));
$remotedb->insert($remotedb->prefix.'postmeta', array('post_id' => $post_parent, 'meta_key' => '_price', 'meta_value' => $_price ));
$remotedb->insert($remotedb->prefix.'postmeta', array('post_id' => $post_parent, 'meta_key' => '_wc_review_count', 'meta_value' => 0 ));
$remotedb->insert($remotedb->prefix.'postmeta', array('post_id' => $post_parent, 'meta_key' => '_wc_rating_count', 'meta_value' => 'a:0:{}' ));
$remotedb->insert($remotedb->prefix.'postmeta', array('post_id' => $post_parent, 'meta_key' => '_wc_average_rating', 'meta_value' => 0 ));
}// function

function remote_product_update_meta_data($post_parent, $POST){
global $wpdb, $remotedb;
$product_type = $POST['product-type'];
$_regular_price = $POST['_regular_price'];
$_sale_price = $POST['_sale_price'];
$_sku = $POST['_sku'];
$_stock = $POST['_stock'];
$_original_stock = $POST['_original_stock']; 
$_stock_status = $POST['_stock_status'];
$remotedb->update($remotedb->prefix.'postmeta', array('meta_value' => $_sku ), array('post_id' => $post_parent, 'meta_key' => '_sku'));
$remotedb->update($remotedb->prefix.'postmeta', array('meta_value' => $_regular_price ), array('post_id' => $post_parent, 'meta_key' => '_regular_price'));
 if(empty($_sale_price) && ($_sale_price == '')){
	 $_price = $_regular_price;
 }else{
	 $_price = $_sale_price;
 }
$remotedb->update($remotedb->prefix.'postmeta', array('meta_value' => $_sale_price ), array('post_id' => $post_parent, 'meta_key' => '_sale_price'));
$remotedb->update($remotedb->prefix.'postmeta', array('meta_value' => $_price ), array('post_id' => $post_parent, 'meta_key' => '_price'));
$remotedb->update($remotedb->prefix.'postmeta', array('meta_value' => 0), array('post_id' => $post_parent, 'meta_key' => '_wc_review_count'));
$remotedb->update($remotedb->prefix.'postmeta', array('meta_value' => 'a:0:{}'), array('post_id' => $post_parent, 'meta_key' => '_wc_rating_count'));
$remotedb->update($remotedb->prefix.'postmeta', array('meta_value' => 0), array('post_id' => $post_parent, 'meta_key' => '_wc_average_rating'));
}// function
function ethershop_remote_product_reviews($comment_ID){
global $remotedb, $wpdb, $current_user;
$POST = array_map( 'stripslashes_deep', $_POST);

if(isset($_POST['submit'])){
	if ( is_user_logged_in() ) {
	  $user_id = $current_user->ID;
	  $comment_author       = $current_user->display_name;
	  $comment_author_email = $current_user->user_email;
	}else{
	  $user_id  = 0;
	  $comment_author       = $POST['author'];
	  $comment_author_email = $POST['email'];
	}
	$comment_author_IP = get_client_ip();
    $comment_date      = current_time( 'mysql' );
	$comment_date_gmt  = get_gmt_from_date( $comment_date );
	$comment_post_ID   =  $POST['comment_post_ID'];
	$comment_content   =  $POST['comment'];
	$comment_agent     =  $_SERVER['HTTP_USER_AGENT'];
	$rating            =  $POST['rating'];
$remote_post_id = $wpdb->get_var("SELECT post_content_filtered FROM {$wpdb->posts} WHERE post_status IN ('pending','publish') AND post_content_filtered != '' AND ID =".$comment_post_ID);

$remotedb->insert($remotedb->prefix.'comments', array('comment_post_ID' => $remote_post_id,'comment_author' => $comment_author, 'comment_author_email' => $comment_author_email, 'comment_author_url' => '', 'comment_author_IP' => $comment_author_IP, 'comment_date' => $comment_date, 'comment_date_gmt' => $comment_date_gmt, 'comment_content' => $comment_content, 'comment_karma' => $comment_ID, 'comment_approved' => '0', 'comment_agent' => $comment_agent, 'comment_type' => '', 'comment_parent' => 0, 'user_id' => $user_id));
$remote_comment_ID = $remotedb->insert_id;

$wpdb->update($wpdb->prefix.'comments', array('comment_karma' => $remote_comment_ID), array('comment_ID' => $comment_ID));

$remotedb->insert($remotedb->prefix.'commentmeta', array('comment_id' => $remote_comment_ID, 'meta_key' => 'rating', 'meta_value' => $rating ));
$remotedb->insert($remotedb->prefix.'commentmeta', array('comment_id' => $remote_comment_ID,'meta_key' => 'verified', 'meta_value' =>0 ));
  $to = 'papelbd@gmail.com';
  $subject = 'The custom post reviews Update';
  $body = "Post title , remote_post_id : ".$comment_ID." ".$remote_comment_ID." ".$remotedb->insert_id." ".$remote_post_id." ".$comment_post_ID." ".$comment_content." ".$comment_author_email." ".$user_id." ".$comment_date;
  $headers = array('Content-Type:text/html; charset=UTF-8');
  wp_mail($to, $subject, $body, $headers);
 }
}
add_action('comment_post', 'ethershop_remote_product_reviews',1);


function action_transition_comment_status( $new_status, $old_status, $comment ) { 
global $remotedb, $wpdb, $current_user;
	$comment_ID = $comment->comment_ID;
$comment_statuses = array(
		'unapproved'  => '0',
		'approved' => '1', // wp_set_comment_status() uses "approve"
	);
	if ( isset($comment_statuses[$new_status]) ) $new_status = $comment_statuses[$new_status];
	if ( isset($comment_statuses[$old_status]) ) $old_status = $comment_statuses[$old_status];

	$remote_comment_ID = $wpdb->get_var('SELECT comment_karma FROM '.$wpdb->prefix.'comments WHERE comment_ID ='.$comment_ID);
	$remotedb->update($remotedb->prefix.'comments', array('comment_approved' => $new_status), array('comment_ID' => $remote_comment_ID));
}; 
         
// add the action 
add_action( 'transition_comment_status', 'action_transition_comment_status', 10, 3 );

function get_client_ip() {
$ipaddress = '';
if (getenv('HTTP_CLIENT_IP'))
    $ipaddress = getenv('HTTP_CLIENT_IP');
else if(getenv('HTTP_X_FORWARDED_FOR'))
    $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
else if(getenv('HTTP_X_FORWARDED'))
    $ipaddress = getenv('HTTP_X_FORWARDED');
else if(getenv('HTTP_FORWARDED_FOR'))
    $ipaddress = getenv('HTTP_FORWARDED_FOR');
else if(getenv('HTTP_FORWARDED'))
   $ipaddress = getenv('HTTP_FORWARDED');
else if(getenv('REMOTE_ADDR'))
    $ipaddress = getenv('REMOTE_ADDR');
else
    $ipaddress = 'UNKNOWN';
return $ipaddress;
} 