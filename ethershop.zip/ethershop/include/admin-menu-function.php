<?php
function get_vendors_by_status( $status ){
global  $wpdb;

if($status == 'all'){
  $status ='';
}else{
  $status = "AND  user_status =".$status;
}
$total = $wpdb->get_var("SELECT COUNT(ID) FROM ".$wpdb->prefix."users, ".$wpdb->prefix."usermeta WHERE ".$wpdb->prefix."users.ID = ".$wpdb->prefix."usermeta.user_id AND meta_key = '".$wpdb->prefix."user_level' AND meta_value = 9 ".$status);
return $total;
}//function close
function get_vendors_withdraw_by_status( $status ){
global  $wpdb;

$total = $wpdb->get_var("SELECT COUNT(id) FROM ".$wpdb->prefix."withdraw WHERE status = '".$status."'");
return $total;
}//function close

function get_vendors_withdraw( $status ){
global $current_user, $wpdb;
$link = admin_url( 'admin.php?page=withdraw');
if($_GET['action']== 'delete'){
 $id = $_GET['id'];
 echo "delete ".$id;
}elseif($_GET['action']== 'approve'){
 $id = $_GET['id'];
 $row = $wpdb->update($wpdb->prefix."withdraw", array('status' => 'approved'), array('id' => $id));
}elseif($_GET['action']== 'cancel'){
 $id = $_GET['id'];
 $row = $wpdb->update($wpdb->prefix."withdraw", array('status' => 'cancelled'), array('id' => $id));
}

$string = get_woocommerce_currency();
$rows = $wpdb->get_results("SELECT * FROM ".$wpdb->prefix."withdraw WHERE status = '".$status."'", ARRAY_A);
	?>
<table class="widefat">
  <tr><td>User</td><td>Amount</td><td>Method</td><td>Method Details</td><td>Note</td><td>IP</td><td>Date</td></tr>
<?php 
if(!empty($rows)){
foreach($rows as $row){ 
$url = admin_url('user-edit.php?user_id='.$row['user_id']);
$user = get_user_by( 'id', $row['user_id']);
$user_login = $user->user_login;
$row_actions = "<div class='row-actions'><span class='delete'><a aria-label='Delete' href='".$link.'&id='.$row['id'].'&action=delete'."'>Delete</a></span>|<span class='edit'><a aria-label='Approve' href='".$link.'&id='.$row['id'].'&action=approve'."'>Approve</a></span>|<span class='cancel'><a class='submitdelete' aria-label='Cancel' href='".$link.'&id='.$row['id'].'&action=cancel'."'>Cancel</a></span></div>";
?>
  <tr><td><a href="<?php echo $url; ?>" ><?php echo $user_login; ?></a>
<?php echo $row_actions; ?>
  </td><td><?php echo $string.$row['amount']; ?></td><td><?php echo $row['method']; ?></td><td><?php echo $row['datails']; ?></td><td><?php echo $row['note']; ?></td><td><?php echo $row['ip']; ?></td><td><?php echo $row['wdate']; ?></td></tr>
 <?php } ?>
</table>
<?php
}else{
  echo "<tr><td clospan='7'><p> No ".$status." transection </p></td></tr>";
}

}//function close


function get_all_vendors( $status ){
global $current_user, $wpdb;
if($status == 'all'){
  $status ='';
}else{
  $status = "AND  user_status =".$status;
}
$users = $wpdb->get_results("SELECT ID, user_login, user_email, user_registered, display_name, user_status FROM ".$wpdb->prefix."users, ".$wpdb->prefix."usermeta WHERE ".$wpdb->prefix."users.ID = ".$wpdb->prefix."usermeta.user_id AND meta_key = '".$wpdb->prefix."user_level' AND meta_value = 9 ".$status."  ORDER BY ".$wpdb->prefix."users.user_registered ASC ");

?>
<table class="vendor widefat">
<tr><td>Username</td><td>Name</td><td>Shop Name</td><td>E-mail</td><td>Products</td><td>Balance</td><td>Phone Number</td><td>Registered</td><td>Status</td></tr>
<?php foreach($users as $user) {
$user_id = $user->ID;
$user_login = $user->user_login;
$fname = get_the_author_meta('first_name', $user_id );
$lname = get_the_author_meta('last_name', $user_id );
$name = $fname." ".$lname;
$store_name = get_the_author_meta('store_name', $user_id );
$user_email = $user->user_email;
$phone_no = get_the_author_meta('phone_no', $user_id );
$registered = $user->user_registered;
$products = count_user_posts( $user_id, 'product' );
$user_status = $user->user_status;
$checked ='';
if($user_status == 1){
 $checked = ' checked ';
}
?>
<tr><td><a href="<?php echo $url; ?>" ><?php echo $user_login; ?></a>
<?php echo $row_actions; ?></td><td><?php echo $name; ?></td><td><?php echo $store_name; ?></td><td><?php echo $user_email; ?></td><td><?php echo $products; ?></td><td><?php echo $balance; ?></td><td><?php echo $phone_no; ?></td><td><?php echo $registered; ?></td><td><input type="checkbox" id="<?php echo $user_id; ?>" name="vendor-switch" <?php echo $checked; ?> /><label for="<?php echo $user_id; ?>"></label></td></tr>
 <?php } ?>
</table>  
<?php

}//close
add_action('wp_ajax_nopriv_switch_vendor_status', 'switch_vendor_status');
add_action('wp_ajax_switch_vendor_status', 'switch_vendor_status');
 
function switch_vendor_status() {
	global $wpdb; //get access to the WordPress database object variable
	//get names of all businesses
	$vendor_switch = stripslashes($_POST['vendor_switch']);
	$user_id = stripslashes($_POST['user_id']); //escape for use in LIKE statement
	$wpdb->update($wpdb->prefix.'users',array('user_status' => $vendor_switch), array('ID' => $user_id));
	die(); //stop "0" from being output
}// function close

function get_all_vendor_ratings(){
  $all_comments = get_comments( array('type' => '', 'number'=>'') );
  //echo "<pre>".print_r($all_comments, 1)."</pre>";
?>
<table class="vendor widefat">
<tr><th>Vendor</th><th>Product</th><th>Customer</th><th>Comments</th><th>Rating</th><th>Date</th></tr>
<?php foreach($all_comments as $comment) {
$productid = $comment->comment_post_ID;
$title = get_the_title($productid);
$user_id = $comment->user_id;
$vendor_id = $author_id = get_post_field ('post_author', $productid);
$display_name = get_the_author_meta( 'display_name' , $vendor_id );
$producturl = get_edit_post_link( $productid );
$vendorurl = admin_url('user-edit.php?user_id='.$vendor_id);
$customerurl = admin_url('user-edit.php?user_id='.$user_id);
$rate = get_comment_meta( $comment->comment_ID, 'rating', true );
$args = array(
   'rating' => $rate,
   'type' => 'rating',
   'number' => 1,
   );
?>
<tr><td><a href="<?php echo $vendorurl; ?>" ><?php echo $display_name; ?></a>
<?php echo $row_actions; ?></td><td><a href="<?php echo $producturl; ?>" ><?php echo $title; ?></a></td><td><a href="<?php echo $customerurl; ?>" ><?php echo $comment->comment_author; ?></a></td><td><?php echo $comment->comment_content; ?></td><td><?php wp_star_rating($args); ?></td><td><?php echo $comment->comment_date; ?></td></tr>
 <?php } ?>
</table>
<?php
}// function close