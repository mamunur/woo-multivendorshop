<?php
add_action( 'woocommerce_checkout_order_processed', 'ethershop_create_remote_order',  10, 3  );
function ethershop_create_remote_order( $order_id, $posted_data, $order) {
global $wpdb, $remotedb;
if(!empty($order_id)):
    //$order = new WC_Order( $order_id );
$order_data = $order->get_data();
if(($posted_data['createaccount'] == 0 ) && !empty($order->get_user_id())){
   $user_id = $order->get_user_id();
   $billing_email = $posted_data['billing_email'];
   $remote_user_id = $remotedb->get_var("SELECT ID FROM ".$remotedb->prefix."users WHERE user_email = '".$billing_email."'");
}elseif($posted_data['createaccount'] == 1 ){
   $remote_user_id = ethershop_create_new_customer($posted_data);
}
$row = $wpdb->get_row("SELECT post_date, post_title, post_status, post_name FROM {$wpdb->posts} WHERE ID = $order_id AND post_type = 'shop_order'", ARRAY_A);

$remotedb->insert($remotedb->prefix.'posts', array('post_author' => 1, 'post_date' => $row['post_date'], 'post_date_gmt' => $row['post_date'], 'post_content' => '', 'post_title' => $row['post_title'], 'post_status' => 'wc-processing', 'post_name' => $row['post_name'], 'post_content_filtered' => $order_id, 'post_parent' => 0, 'guid' => '', 'post_type' => 'shop_order', 'post_mime_type' => ''));
$orderid = $remotedb->insert_id;
$wpdb->update($wpdb->prefix.'posts', array('post_content_filtered' => $orderid), array('post_type' => 'shop_order', 'ID' => $order_id));
$metarow = $wpdb->get_results("SELECT meta_key, meta_value FROM {$wpdb->postmeta} WHERE post_id = $order_id AND meta_value <> '' ", ARRAY_A);
 foreach($metarow as $value):
   //echo $value['meta_key'] .' => '.$value['meta_value'].'<br/>';
   $remotedb->insert($remotedb->prefix.'postmeta', array('post_id' => $orderid, 'meta_key' => $value['meta_key'], 'meta_value' => $value['meta_value'] ));
 endforeach;
$orderitem = $wpdb->get_results("SELECT * FROM ".$wpdb->prefix."woocommerce_order_items WHERE order_id = $order_id", ARRAY_A);
 foreach($orderitem as $value):
//echo $value['meta_key'] .' => '.$value['meta_value'].'<br/>';
$wpdb->insert($wpdb->prefix.'woocommerce_order_itemmeta', array('order_item_id' => $value['order_item_id'], 'meta_key' => 'vendor_order_status', 'meta_value' => 'Processig' ));

$remotedb->insert($remotedb->prefix.'woocommerce_order_items', array('order_item_name' => $value['order_item_name'], 'order_item_type' => $value['order_item_type'], 'order_id' => $orderid ));
$order_item_id = $remotedb->insert_id;
  $item_meta = $wpdb->get_results("SELECT meta_key , meta_value FROM ".$wpdb->prefix."woocommerce_order_itemmeta WHERE order_item_id =". $value['order_item_id'], ARRAY_A);

  foreach($item_meta as $meta_value):
    if($meta_value['meta_key'] == '_product_id'){
	  $_product_id = $meta_value['meta_value'];
	  $remotedb_product_id = $wpdb->get_var("SELECT post_content_filtered FROM {$wpdb->posts} WHERE post_type = 'product' AND ID = $_product_id");
	  $remotedb->insert($remotedb->prefix.'woocommerce_order_itemmeta', array('order_item_id' => $order_item_id, 'meta_key' => $meta_value['meta_key'], 'meta_value' => intval($remotedb_product_id) ));
	}else{
	$remotedb->insert($remotedb->prefix.'woocommerce_order_itemmeta', array('order_item_id' => $order_item_id, 'meta_key' => $meta_value['meta_key'], 'meta_value' => $meta_value['meta_value'] ));
	}
  endforeach;
 endforeach;
 
 $order_note = $wpdb->get_row("SELECT comment_content,comment_author_IP, comment_date, comment_date_gmt FROM ".$wpdb->prefix."comments WHERE comment_type ='order_note' AND comment_post_ID=".$order_id, ARRAY_A);
 $remotedb->insert($remotedb->prefix.'comments', array('comment_post_ID' => $orderid, 'comment_author' => 'WooCommerce', 'comment_author_email' => 'woocommerce@ilovebarnwood.com', 'comment_author_IP' => $order_note['comment_author_IP'], 'comment_date' => $order_note['comment_date'], 'comment_date_gmt' => $order_note['comment_date_gmt'], 'comment_content' => $order_note['comment_content'], 'comment_approved' => 1, 'comment_agent' => 'WooCommerce', 'comment_type' => 'order_note', 'comment_parent' => 0, 'user_id' => $remote_user_id));
	$to = 'papelbd@gmail.com';
	$subject = 'new Order Created';
	$body = "new Remote Order " .$order_item_id." ".$remotedb_product_id;
	$headers = array('Content-Type: text/html; charset=UTF-8');
	wp_mail($to, $subject, $body, $headers);
endif;    // etc...
}//function close
function ethershop_create_new_customer($posted_data) {
global $current_user, $remotedb;
$email = $posted_data['billing_email'];
$account_password = $posted_data['account_password'];
$hashedPassword = wp_hash_password($account_password);
$parts = explode("@", $email);
$username = $parts[0];
$remotedb->insert($remotedb->prefix.'users', array('user_login' => $username, 'user_pass' =>  $hashedPassword, 'user_nicename' => $username, 'user_email' => $email, 'user_status' => 0, 'display_name' => $username));
   $id = $remotedb->insert_id;
   $capabilities = $remotedb->prefix.'capabilities';
   $user_level = $remotedb->prefix.'user_level';
   $remotedb->insert($remotedb->prefix.'usermeta', array('user_id' => $id, 'meta_key' => $capabilities, 'meta_value' => 'a:1:{s:8:"customer";b:1;}'));
   $remotedb->insert($remotedb->prefix.'usermeta', array('user_id' => $id, 'meta_key' => $user_level, 'meta_value' => '0'));
   $remotedb->insert($remotedb->prefix.'usermeta', array('user_id' => $id, 'meta_key' => 'first_name', 'meta_value' => sanitize_text_field( $posted_data['billing_first_name'])));
   $remotedb->insert($remotedb->prefix.'usermeta', array('user_id' => $id, 'meta_key' => 'last_name', 'meta_value' => sanitize_text_field( $posted_data['billing_last_name'])));
   $remotedb->insert($remotedb->prefix.'usermeta', array('user_id' => $id, 'meta_key' => 'billing_country', 'meta_value' => sanitize_text_field( $posted_data['billing_country'])));
   $remotedb->insert($remotedb->prefix.'usermeta', array('user_id' => $id, 'meta_key' => 'billing_address_1', 'meta_value' => sanitize_text_field( $posted_data['billing_address_1'])));
   $remotedb->insert($remotedb->prefix.'usermeta', array('user_id' => $id, 'meta_key' => 'billing_city', 'meta_value' => sanitize_text_field( $posted_data['billing_city'])));
   $remotedb->insert($remotedb->prefix.'usermeta', array('user_id' => $id, 'meta_key' => 'billing_state', 'meta_value' => sanitize_text_field( $posted_data['billing_state'])));
  $remotedb->insert($remotedb->prefix.'usermeta', array('user_id' => $id, 'meta_key' => 'billing_postcode', 'meta_value' => sanitize_text_field( $posted_data['billing_postcode'])));
   $remotedb->insert($remotedb->prefix.'usermeta', array('user_id' => $id, 'meta_key' => 'billing_phone', 'meta_value' => sanitize_text_field( $posted_data['billing_phone'])));
   
 return $id;
}
add_action('wp_ajax_nopriv_save_vendor_order_action', 'save_vendor_order_action_callback');
add_action('wp_ajax_save_vendor_order_action', 'save_vendor_order_action_callback');
function save_vendor_order_action_callback() {
global $wpdb, $current_user, $remotedb;
$order_action = isset($_REQUEST['wc_order_action'])? htmlentities($_REQUEST['wc_order_action']) : '';
$order_id = $_REQUEST['order_id'];
$user_id = $current_user->ID;
$vendor_email = $current_user->user_email;
$remote_vendor_id = $remotedb->get_var("SELECT ID FROM ".$remotedb->prefix."users WHERE user_email = '".$vendor_email."'");
$remote_order_id = $remotedb->get_var("SELECT ID FROM {$remotedb->posts} WHERE post_type = 'shop_order' AND  post_content_filtered= {$order_id}");
$line_subtotal = 0;

if($order_action == 'mark_shipped'){
$orderitem = $wpdb->get_results("SELECT * FROM ".$wpdb->prefix."woocommerce_order_items WHERE order_id = $order_id", ARRAY_A);
 foreach($orderitem as $value):
  $item_meta = $wpdb->get_row("SELECT meta_key , meta_value FROM ".$wpdb->prefix."woocommerce_order_itemmeta WHERE meta_key = '_product_id' AND order_item_id =". $value['order_item_id'], ARRAY_A);
	$_product_id = $item_meta['meta_value'];
	$vendor_id = get_post_field( 'post_author', $_product_id );
	if($vendor_id == $user_id){
	 $wpdb->update($wpdb->prefix."woocommerce_order_itemmeta", array( 'meta_value' => 'Shipped'), array( 'meta_key' => 'vendor_order_status', 'order_item_id' => $value['order_item_id']));
	 $line_subtotal += $wpdb->get_var("SELECT meta_value FROM ".$wpdb->prefix."woocommerce_order_itemmeta WHERE order_item_id = ".$value['order_item_id']." AND meta_key = '_line_subtotal'");
	}
 endforeach;
 $vendor_balance = get_user_meta( $vendor_id, 'vendor_balance', true );
 $vendor_balance  += $line_subtotal;
 update_user_meta( $vendor_id, 'vendor_balance', $vendor_balance );
 
$remoteorderitem = $remotedb->get_results("SELECT * FROM ".$remotedb->prefix."woocommerce_order_items WHERE order_id = $remote_order_id", ARRAY_A);

 foreach($remoteorderitem as $value):
  $item_meta = $remotedb->get_row("SELECT meta_key , meta_value FROM ".$remotedb->prefix."woocommerce_order_itemmeta WHERE meta_key = '_product_id' AND order_item_id =". $value['order_item_id'], ARRAY_A);
	$_product_id = $item_meta['meta_value'];
	$product_author = remote_product_vendor_id($_product_id );
	if($product_author == $remote_vendor_id){
	 $remotedb->update($remotedb->prefix."woocommerce_order_itemmeta", array( 'meta_value' => 'Shipped'), array( 'meta_key' => 'vendor_order_status', 'order_item_id' => $value['order_item_id']));
	 $remote_line_subtotal += $remotedb->get_var("SELECT meta_value FROM ".$remotedb->prefix."woocommerce_order_itemmeta WHERE order_item_id = ".$value['order_item_id']." AND meta_key = '_line_subtotal'");
	}
 endforeach; 
  $vendor_balance = $remotedb->get_var("SELECT meta_value FROM {$remotedb->usermeta} WHERE user_id = ".$remote_vendor_id." AND meta_key= 'vendor_balance'");
 if(empty($vendor_balance)){
   $remotedb->insert($remotedb->prefix."usermeta", array('meta_key' => 'vendor_balance', 'meta_value' => $remote_line_subtotal,  'user_id' => $remote_vendor_id));
 }else{
   $vendor_balance += $remote_line_subtotal;
   $remotedb->update($remotedb->prefix."usermeta", array( 'meta_value' => $vendor_balance), array('meta_key' => 'vendor_balance','user_id' => $remote_vendor_id));
 }
  //echo "new_status " .$order_action." for ".$order_id;
  echo "success";
}

die;
}

function remote_product_vendor_id($product_id) {
global $remotedb;
$post_author = $remotedb->get_var("SELECT post_author FROM {$remotedb->posts} WHERE ID = ".$product_id." AND post_type= 'product'");
return $post_author;
}//close

