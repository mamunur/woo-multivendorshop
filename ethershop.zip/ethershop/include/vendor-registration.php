<?php
function ethershop_vendor_registration_fields() {?>
<div class="vendor-display">
   <p class="woocommerce-FormRow woocommerce-FormRow--wide form-row form-row-wide">
   <input type="text" class="woocommerce-Input woocommerce-Input--text input-text form-control" name="billing_phone" id="reg_billing_phone" value="<?php esc_attr_e( $_POST['billing_phone'] ); ?>" placeholder="Phone" />
   </p>
   <p class="woocommerce-FormRow woocommerce-FormRow--wide form-row form-row-wide">
   <input type="text" class="woocommerce-Input woocommerce-Input--text input-text form-control" name="billing_first_name" id="reg_billing_first_name" value="<?php if ( ! empty( $_POST['billing_first_name'] ) ) esc_attr_e( $_POST['billing_first_name'] ); ?>" placeholder="First name *" />
   </p>
   <p class="woocommerce-FormRow woocommerce-FormRow--wide form-row form-row-wide">
   <input type="text" class="woocommerce-Input woocommerce-Input--text input-text form-control" name="billing_last_name" id="reg_billing_last_name" value="<?php if ( ! empty( $_POST['billing_last_name'] ) ) esc_attr_e( $_POST['billing_last_name'] ); ?>" placeholder="Last name *" />
   </p>
</div>
<p class="form-row form-row-wide">
<label><input type="radio" checked="checked" name="user_type" value="c" />I am customer </label>
<label>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="user_type" value="v" />I am vendor</label>
</p>
       <div class="clear"></div>
       <?php
 }
 add_action( 'woocommerce_register_form', 'ethershop_vendor_registration_fields' );
function ethershop_vendor_validate_reg_form_fields($username, $email, $validation_errors) {
 if ($_POST['user_type']=="v") {
  if (isset($_POST['billing_first_name']) && empty($_POST['billing_first_name'])) {
        $validation_errors->add('billing_first_name_error', __('<strong>Error</strong>: First name is required!', 'text_domain'));
  }
  if (isset($_POST['billing_last_name']) && empty($_POST['billing_last_name'])) {
        $validation_errors->add('billing_last_name_error', __('<strong>Error</strong>: Last name is required!.', 'text_domain'));
  }
 }
    return $validation_errors;
}

add_action('woocommerce_register_post', 'ethershop_vendor_validate_reg_form_fields', 10, 3);
function ethershop_new_customer_data($new_customer_data){
    if ($_POST['user_type']=="c") {
	 $new_customer_data['role'] = 'customer';
	}elseif ($_POST['user_type']=="v") {
	 $new_customer_data['role'] = 'vendor';
	}
   return $new_customer_data;
}
add_filter( 'woocommerce_new_customer_data', 'ethershop_new_customer_data');

add_action( 'admin_bar_menu', 'toolbar_link_to_mypage', 999 );

function toolbar_link_to_mypage( $wp_admin_bar ) {
 global $current_user;
 $url = admin_url('admin.php?page=vendor_dashboard');
	$args = array(
		'id'    => 'vendor_dashboard',
		'title' => 'Vendor Dashboard',
		'href'  => $url,
		'meta'  => array( 'class' => 'my-toolbar-page' )
	);
   if ( in_array( 'vendor', $current_user->roles ) ) {
	$wp_admin_bar->add_node( $args );
   }
}

function ethershop_remove_account_dadshboard(){
global $current_user;
  if ( in_array( 'vendor', $current_user->roles ) ) {
    remove_action( 'woocommerce_account_content', 'woocommerce_account_content' );
	add_action( 'woocommerce_account_content', 'ethershop_account_content' );
  }
}
add_action( 'woocommerce_account_navigation', 'ethershop_remove_account_dadshboard', 1 );
function ethershop_account_content() {
global $current_user, $remotedb, $vendor_id;
$url = admin_url('admin.php?page=vendor_dashboard');
?>
<p>
Hello <strong><?php echo $current_user->user_login; ?></strong> ( not <?php echo $current_user->user_login; ?> ? ) <a href="/my-account/customer-logout/"> Log out</a>
</p>
<p>Go To Vendor Dashboard <a href="<?php echo $url; ?>">vendor dashboard</a>
<?php
$email = $current_user->user_email;
$vendor_id = $remotedb->get_var("SELECT `ID` FROM ".$remotedb->prefix."users WHERE `user_email` ='".$email."'");
//echo "Remote ".$vendor_id." email".$email;
//echo "<pre>".print_r($remotedb, 1)."</pre>";
?>
<p>From your account dashboard you can <a href="/my-account/edit-account/">edit your password and account details.</a></p>
<?php
}

function ethershop_save_extra_register_fields( $customer_id ) {
global $current_user, $remotedb;
$email = sanitize_text_field( $_POST['email'] );
$password = sanitize_text_field( $_POST['password'] );
$hashedPassword = wp_hash_password($password);
$parts = explode("@", $email);
$username = $parts[0];
    if ( isset( $_POST['billing_first_name'] ) ) {
        // WordPress default first name field.
        update_user_meta( $customer_id, 'first_name', sanitize_text_field( $_POST['billing_first_name'] ) );
        // WooCommerce billing first name.
        update_user_meta( $customer_id, 'billing_first_name', sanitize_text_field( $_POST['billing_first_name'] ) );
    }
    if ( isset( $_POST['billing_last_name'] ) ) {
        // WordPress default last name field.
        update_user_meta( $customer_id, 'last_name', sanitize_text_field( $_POST['billing_last_name'] ) );

        // WooCommerce billing last name.
        update_user_meta( $customer_id, 'billing_last_name', sanitize_text_field( $_POST['billing_last_name'] ) );
    }
    if ( isset( $_POST['billing_phone'] ) ) {
        // WooCommerce billing phone
        update_user_meta( $customer_id, 'billing_phone', sanitize_text_field( $_POST['billing_phone'] ) );
    }
$remotedb->insert($remotedb->prefix.'users', array('user_login' => $username, 'user_pass' =>  $hashedPassword, 'user_nicename' => $username, 'user_email' => $email, 'user_status' => 2, 'display_name' => $username));
   $id = $remotedb->insert_id;
   $capabilities = $remotedb->prefix.'capabilities';
   $user_level = $remotedb->prefix.'user_level';
   $remotedb->insert($remotedb->prefix.'usermeta', array('user_id' => $id, 'meta_key' => $capabilities, 'meta_value' => 'a:1:{s:6:"vendor";b:1;}'));
   $remotedb->insert($remotedb->prefix.'usermeta', array('user_id' => $id, 'meta_key' => $user_level, 'meta_value' => '9'));
   $remotedb->insert($remotedb->prefix.'usermeta', array('user_id' => $id, 'meta_key' => 'first_name', 'meta_value' => sanitize_text_field( $_POST['billing_first_name'])));
   $remotedb->insert($remotedb->prefix.'usermeta', array('user_id' => $id, 'meta_key' => 'last_name', 'meta_value' => sanitize_text_field( $_POST['billing_last_name'])));
   $remotedb->insert($remotedb->prefix.'usermeta', array('user_id' => $id, 'meta_key' => 'billing_phone', 'meta_value' => sanitize_text_field( $_POST['billing_phone'])));
}

add_action( 'woocommerce_created_customer', 'ethershop_save_extra_register_fields' );