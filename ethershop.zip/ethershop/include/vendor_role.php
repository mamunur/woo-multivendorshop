<?php
function set_ethershop_options(){
$role = add_role('vendor', __('Vendor', 'ethershop'), array(
    'level_0' => true,
	'level_1' => true,
	'level_2' => true,
	'level_3' => true,
	'level_4' => true,
	'level_5' => true,
	'level_6' => true,
	'level_7' => true,
	'level_8' => true,
	'level_9' => true,
    'read' => true,
    'read_private_pages'    => true,
    'read_private_posts'    => true,
    'edit_posts' => true,
    'edit_pages' => true,
    'edit_published_posts'  => true,
    'edit_published_pages'  => true,
    'edit_private_pages'    => true,
    'edit_private_posts'    => true,
    'edit_others_posts' => true,
    'edit_others_pages' => true,
    'publish_posts' => true,
    'publish_pages' => true,
    'delete_posts' => true,
    'delete_pages' => true,
    'delete_private_pages'  => true,
    'delete_private_posts'  => true,
    'delete_published_pages'    => true,
    'delete_published_posts'    => true,
    'delete_others_posts' => true,
    'delete_others_pages' => true,
    'manage_categories' => true,
    'manage_links'  => true,
    'moderate_comments' => true,
    'unfiltered_html'   => true,
    'upload_files'  => true,
    'export'    => true,
    'import'    => true,
    'manage_woocommerce'    => true,
    'manage_woocommerce_orders' => true,
    'manage_woocommerce_coupons'    => true,
    'manage_woocommerce_products'   => true,
    'view_woocommerce_reports'  => true,
    'edit_product' => true,
    'read_product' => true,
    'delete_product' => true,
    'edit_products' => true,
    'edit_others_products' => true,
    'publish_products' => true,
    'read_private_products' => true,
    'delete_products' => true,
    'delete_private_products' => true,
    'delete_published_products' => true,
    'delete_others_products' => true,
    'edit_private_products' => true,
    'edit_published_products' => true,
    'manage_product_terms' => true,
    'edit_product_terms' => true,
    'delete_product_terms' => true,
    'assign_product_terms' => true,
    'edit_shop_order' => true,
    'read_shop_order' => true,
    'delete_shop_order' => true,
    'edit_shop_orders' => true,
    'edit_others_shop_orders' => true,
    'publish_shop_orders' => true,
    'read_private_shop_orders' => true,
    'delete_shop_orders' => true,
    'delete_private_shop_orders' => true,
    'delete_published_shop_orders' => true,
    'delete_others_shop_orders' => true,
    'edit_private_shop_orders' => true,
    'edit_published_shop_orders' => true,
    'manage_shop_order_terms' => true,
    'edit_shop_order_terms' => true,
    'delete_shop_order_terms' => true,
    'assign_shop_order_terms' => true,
    'edit_shop_coupon' => true,
    'read_shop_coupon' => true,
    'delete_shop_coupon' => true,
    'edit_shop_coupons' => true,
    'edit_others_shop_coupons' => true,
    'publish_shop_coupons' => true,
    'read_private_shop_coupons' => true,
    'delete_shop_coupons' => true,
    'delete_private_shop_coupons' => true,
    'delete_published_shop_coupons' => true,
    'delete_others_shop_coupons' => true,
    'edit_private_shop_coupons' => true,
    'edit_published_shop_coupons' => true,
    'manage_shop_coupon_terms' => true,
    'edit_shop_coupon_terms' => true,
    'delete_shop_coupon_terms' => true,
    'assign_shop_coupon_terms' => true,
    'edit_shop_webhook' => true,
    'read_shop_webhook' => true,
    'delete_shop_webhook' => true,
    'edit_shop_webhooks' => true,
    'edit_others_shop_webhooks' => true,
    'publish_shop_webhooks' => true,
    'read_private_shop_webhooks' => true,
    'delete_shop_webhooks' => true,
    'delete_private_shop_webhooks' => true,
    'delete_published_shop_webhooks' => true,
    'delete_others_shop_webhooks' => true,
    'edit_private_shop_webhooks' => true,
    'edit_published_shop_webhooks' => true,
    'manage_shop_webhook_terms' => true,
    'edit_shop_webhook_terms' => true,
    'delete_shop_webhook_terms' => true,
    'assign_shop_webhook_terms' => true
    ));
}// function close

function add_my_rule() {    
    global $wp; 
    $wp->add_query_var('tags');
    add_rewrite_rule('vendor/([^/]*)','index.php?pagename=vendor&urltags=$matches[1]','top');
}
function add_my_tags() {
    add_rewrite_tag('%urltags%', '([^&]+)');
}
add_action('init', 'add_my_rule');
add_action('init', 'add_my_tags', 10, 0);
function ethershop_vendor_product_listing_shortcode_function($attr) {
 $output ="";
 $loop ="";
 global $wpdb;
ob_start();
//echo $search_result->found_posts;
//echo "<pre>".print_r($sub_cats, 1)."</pre>";
$vendor_login = get_query_var( 'urltags' );
$user = get_user_by( login, $vendor_login );
$user_id = $user->ID;
if(empty($user_id)){
  return;
}
    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

    $args = array(
        'post_type' => 'product',
        'paged' => $paged,
		'author' => $user_id,
		'post_status' => 'publish',
  		'orderby' 	  => 'post_date',
  		'order' 	  => 'DESC'
    );
    $wp_query = new WP_Query($args);
	//echo "<pre>".print_r($wp_query,1)."</pre>";
        ?>
<div class="container page-container">
	<div class="row">
		<div class="col-md-9 col-sm-12">
<?php
	$count_key = 'vendor_views_count';
    $count = get_user_meta($user_id, $count_key, true);
	$count++;
    update_user_meta($user_id, $count_key, $count);	
    do_action('woocommerce_archive_description'); ?>

        <?php if ( $wp_query->have_posts() ) : ?>
            <?php
            // I don't want the sorting anymore
            //do_action('woocommerce_before_shop_loop');
            ?>
            <ul class = "products-list">
   <?php while ( $wp_query->have_posts() ) : $wp_query->the_post();  ?>
      <?php woocommerce_get_template_part('content', 'product'); ?>
   <?php endwhile; // end of the loop.   ?>
            </ul>
            <?php
            /*  woocommerce pagination  */
            do_action('woocommerce_after_shop_loop');
            ?>
        <?php elseif (!woocommerce_product_subcategories(array('before' => woocommerce_product_loop_start(false), 'after' => woocommerce_product_loop_end(false)))) : ?>
            <?php woocommerce_get_template('loop/no-products-found.php'); ?>
        <?php endif; ?>
		</div>
	<?php get_sidebar( 'shop' ); ?>
	</div>
</div>


<?php
return ob_get_clean();
}
add_shortcode( 'ethershop_vendor_product_listing', 'ethershop_vendor_product_listing_shortcode_function');


add_shortcode( 'ethershop_vendor_list', 'ethershop_vendor_list_shortcode_function');
function ethershop_vendor_list_shortcode_function($attr) {
 $output ="";
 $loop ="";
 global $wpdb;
ob_start();
//echo $search_result->found_posts;
//echo "<pre>".print_r($sub_cats, 1)."</pre>";
$vendor_login = get_query_var( 'urltags' );
if(empty($vendor_login)):
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$args = array(
    'role'    => 'vendor',
    'orderby' => 'user_nicename',
    'order'   => 'ASC'
);
$users = get_users( $args );
	//echo "<pre>".print_r($wp_query,1)."</pre>";
        ?>
<div class="container page-container">
	<div class="row">
		<div class="col-md-12 col-sm-12">
<?php
echo '<ul class="vendor-list">';
foreach ( $users as $user ) {
$store_banner = '';
$url = site_url('vendor/'.$user->user_login);
 $profile_picture = get_user_meta( $user->ID, 'profile_picture', true );
 $store_banner =  get_user_meta( $user->ID, 'store_banner', true );
 $store_name =  get_user_meta( $user->ID, 'store_name', true );	
 $street  =	get_user_meta( $user->ID, 'street', true );
 $city  =  get_user_meta( $user->ID, 'city', true );
 $town =  get_user_meta( $user->ID, 'town', true );
 $zip = get_user_meta( $user->ID, 'zip', true );
 $country  = get_user_meta( $user->ID, 'country_field', true );
 $phone_no	= get_user_meta( $user->ID, 'phone_no', true );
 $medium = $image = array();
 if(isset($store_banner) && !empty($store_banner)){
	$full   = wp_get_attachment_image_src($store_banner, "full");
	$medium = wp_get_attachment_image_src($store_banner, "medium");
 }
 if(isset($profile_picture) && !empty($profile_picture)){
    $image = wp_get_attachment_image_src($profile_picture, "medium");
 }
?>
<li class="col-md-4 col-sm-6"><div class="store-content"><div class="store-info" style="background-image:url(<?php echo $medium[0]; ?>);">
<div class="store-data-container">
<div class="store-data">
<h3><a href="<?php echo $url; ?>"><?php echo $store_name; ?></a></h3>
<p class="store-address"><span class="street"><?php echo $street; ?></span>
<span class="city"><?php echo $city; ?></span>
<span class="town"><?php echo $town; ?></span>
<span class="zip"><?php echo $zip; ?></span>
</p>
<p class="store-phone"><?php echo $phone_no; ?></p>
</div>
</div>
</div>
<div class="store-footer"><div class="seller-avatar"><img src="<?php echo $image[0]; ?>"  /></div>
<a href="<?php echo $url; ?>" class="btn button-primary store-btn" >Visit Store</a>
</div><!--store-footer-->
</div></li>
<?php
}
echo '</ul>';
?>
		</div>
	</div>
</div>
<?php
endif;
return ob_get_clean();
}
