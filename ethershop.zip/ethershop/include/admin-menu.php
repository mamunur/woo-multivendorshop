<?php
add_action( 'admin_menu', 'ethershop_administrator_menu' );
function ethershop_administrator_menu() {
global $wpdb, $current_user;
 if ( in_array( 'administrator', $current_user->roles ) ) {
	add_menu_page(
		__( 'EtherShop', 'ethershop' ),
		__( 'EtherShop', 'ethershop' ),
		'manage_options',
		'administrator_dashboard',
		'administrator_dashboard_page',
		plugins_url( 'inventory_management/images/elite-icon-old.png' ),
		'7'
	);
 add_submenu_page('administrator_dashboard', 'DashBoard', 'DashBoard', 'manage_options', 'administrator_dashboard' );
//add_submenu_page( 'inventory_admin', 'Add New Item', "<i class='fa fa-folder-open'></i>All Item", 'manage_woocommerce', '', 'edit.php?post_type=shop_order');
//add_submenu_page( 'inventory_admin', __( 'Booking', 'woocommerce' ), __( 'Booking', 'woocommerce' ), 'manage_product_terms', 'edit.php?post_type=shop_order' );
add_submenu_page( 'administrator_dashboard', 'All Vendors', "<i class='fa fa-folder-open'></i>Vendors", 'manage_options', 'all_vendors', 'all_vendors_page' );
add_submenu_page( 'administrator_dashboard', 'Withdraw', "<i class='fa fa-folder-open'></i>Withdraw", 'manage_options', 'withdraw', 'withdraw_page' );
add_submenu_page( 'administrator_dashboard', 'Announcements', "<i class='fa fa-folder-open'></i>Announcements", 'manage_options',  'edit.php?post_type=announcement' );
add_submenu_page( 'administrator_dashboard', 'Vendors Ratings', "<i class='fa fa-gears'></i> Vendors Ratings", 'manage_options', 'vendors_ratings','vendors_ratings_page' );
add_submenu_page( 'administrator_dashboard', 'Options Setting', "<i class='fa fa-gears'></i> Options Setting", 'manage_options', 'option_setting','option_setting_page' );

}
}// function close
function administrator_dashboard_page() {
global $current_user;
$vendors_all = get_vendors_by_status('all');
$vendors_active = get_vendors_by_status(1);
$vendors_inactive = get_vendors_by_status(2);
$pending = get_vendors_withdraw_by_status('pending');
$approved = get_vendors_withdraw_by_status('approved');
$cancelled = get_vendors_withdraw_by_status('cancelled');
   ?>
 <div id="dashboard-widgets-wrap">
  <div id="dashboard-widgets" class="metabox-holder">
   <div id="postbox-container-1" class="postbox-container">
    <div id="normal-sortables" class="meta-box-sortables ui-sortable">
	 <div id="dashboard_right_now" class="postbox ">
	  <button class="handlediv" type="button" aria-expanded="true">
	   <span class="screen-reader-text"></span>
	   <span class="toggle-indicator" aria-hidden="true"></span>
	  </button>
	  <h2 class="hndle ui-sortable-handle"><span>At a Glance</span></h2>
	  <div class="inside">
	<div class="main">
	<ul class="vendors_glance">
	<div class="vendors">Vendors</div>
	<li class="total"><a href="edit.php?post_type=page"><?php echo $vendors_all; ?> Total Vendors</a></li>
	<li class="active"><a href="edit.php?post_type=page"><?php echo $vendors_active; ?> Active Vendors</a></li>
	<li class="inactive"><a href="edit.php?post_type=page"><?php echo $vendors_inactive; ?> Inactive Vendors</a></li>
	</ul>
	<ul class="withdraw_glance">
	<div class="vendors">Withdraw</div>
	<li class="total"><a href="edit.php?post_type=page"><?php echo $pending; ?> Pending Withdraw</a></li>
	<li class="active"><a href="edit.php?post_type=page"><?php echo $approved; ?> Approved Withdraw</a></li>
	<li class="inactive"><a href="edit.php?post_type=page"><?php echo $cancelled; ?> Cancelled Withdraw</a></li>
	</ul>
	</div>
	</div>
	 </div>
	</div>
   </div>
<div id="postbox-container-2" class="postbox-container"><div id="side-sortables" class="meta-box-sortables ui-sortable">
<div id="dashboard_quick_press" class="postbox ">
<button type="button" class="handlediv" aria-expanded="true"><span class="screen-reader-text">Toggle panel: <span class="hide-if-no-js">Overview</span> <span class="hide-if-js">Your Recent Drafts</span></span><span class="toggle-indicator" aria-hidden="true"></span></button><h2 class="hndle ui-sortable-handle"><span><span class="hide-if-no-js">Overview</span> <span class="hide-if-js">Your Recent Drafts</span></span></h2>
    <div class="inside">
      <div class="main">
		<?php //echo "<pre>".print_r($current_user, 1)."</pre>"; ?>
	  </div>	
	</div>
</div><!--dashboard_quick_press-->

</div>	</div>
  </div>
 </div>  
   <?php
}
function withdraw_page() {
$link = admin_url( 'admin.php?page=withdraw');
echo "<p><i>Approve or Decline Withdraw Requests sent by vendors.</i></p><br/>"; ?>
   <ul class="withdraw-sub_menu"><li><a href="<?php echo $link; ?>&type=pending">Pending</a></li> | <li><a href="<?php echo $link; ?>&type=approved">Approved</a></li> | <li><a href="<?php echo $link; ?>&type=cancelled">Cancelled</a></li></ul>
<?php if(($_GET['type'] == 'pending') || ($_GET['type'] == '')){
    get_vendors_withdraw( 'pending' );
 }elseif(($_GET['type'] == 'approved')){
    get_vendors_withdraw( 'approved' );
 }elseif(($_GET['type'] == 'cancelled')){
    get_vendors_withdraw( 'cancelled' );
 }
}//function close
function all_vendors_page() {
    $link = admin_url( 'admin.php?page=all_vendors');
	$total = get_vendors_by_status('all');
	$approved = get_vendors_by_status(1);
	$pending = get_vendors_by_status(2);
   ?>
<ul class="withdraw-sub_menu"><li><a href="<?php echo $link; ?>&type=all">All (<?php echo $total; ?>)</a></li>|<li><a href="<?php echo $link; ?>&type=approved">Approved (<?php echo $approved; ?>)</a></li>|<li><a href="<?php echo $link; ?>&type=pending">Pending (<?php echo $pending; ?>)</a></li></ul>   
   <?php
if(($_GET['type'] == 'all') || ($_GET['type'] == '')){
    get_all_vendors( 'all' );
 }elseif(($_GET['type'] == 'approved')){
    get_all_vendors(1);
 }elseif(($_GET['type'] == 'pending')){
    get_all_vendors(2);
}
}//function close

function vendors_ratings_page() {
    get_all_vendor_ratings();
}
function option_setting_page() {
  ?>
  <div class="tabs">
   <div class="tab">
       <input type="radio" id="tab-1" name="tab-group-1" checked>
       <label for="tab-1">General</label>
       <div class="content">
         <?php setting_general(); ?>
       </div> 
   </div>
   <div class="tab">
       <input type="radio" id="tab-2" name="tab-group-1">
       <label for="tab-2">Product</label>
       <div class="content">
         <?php setting_product(); ?>
       </div> 
   </div>
    <div class="tab">
       <input type="radio" id="tab-3" name="tab-group-1">
       <label for="tab-3">Selling Options</label>
       <div class="content">
         <?php selling_options(); ?>
       </div> 
   </div>
   <div class="tab">
       <input type="radio" id="tab-4" name="tab-group-1">
       <label for="tab-4">Withdraw Options</label>
       <div class="content">
         <?php withdraw_options(); ?>
       </div> 
   </div>
  </div><!--tabs-->
  <?php
}