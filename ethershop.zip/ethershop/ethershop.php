<?php   
/* Plugin Name: EtherShop
Plugin URI: http://fixrunner.com/wpoptinever/
Description: Handling Store and Inventory API functioning.
Version: 1.2.2
Author: Md Mamunur Rahman
Author URI: http://fixrunner.com/
Min WP Version: 3.6
Max WP Version: 4.2.0
*/


register_activation_hook(__FILE__,'set_ethershop_options');
if( !defined('ETHERSHOP_DIR') ){
	define( 'ETHERSHOP_DIR', plugins_url() . '/ethershop/' );
}

if( !defined('LISTING_ADMIN_DIR') ){
	define( 'LISTING_ADMIN_DIR', ETHERSHOP_DIR . 'admin/' );
}
if( !defined("ETHERSHOP_JS_DIR") ){
	define("ETHERSHOP_JS_DIR", ETHERSHOP_DIR . "js/");
}

if( !defined("ETHERSHOP_CSS_DIR") ){
	define("ETHERSHOP_CSS_DIR", ETHERSHOP_DIR . "css/");
}
function ethershop_admin_scripts($hook_suffix){
	wp_enqueue_script( 'jquery' );
		wp_enqueue_script( 'jquery-ui' );
		wp_enqueue_script( 'jquery-ui-core' );
		wp_enqueue_script( 'jquery-ui-tabs' );
		wp_enqueue_script( 'jquery-ui-sortable' );
		wp_enqueue_script( 'jquery-ui-progressbar' );
		wp_enqueue_script( 'jquery-ui-widget' );
		wp_enqueue_script( 'jquery-ui-tabs' );
		wp_enqueue_script( 'jquery-ui-slider' );
		wp_enqueue_script( 'jquery-ui-dialog' );
		wp_enqueue_script( 'wp-color-picker' );	
    	wp_enqueue_media();
        wp_enqueue_script('thickbox');
wp_register_style( 'ethershop_admin_styles', WC()->plugin_url() . '/assets/css/admin.css', array(), WC_VERSION );
wp_enqueue_style( 'ethershop_admin_styles' );
wp_register_style('admin_styles', ETHERSHOP_CSS_DIR. 'admin_style.css', array(), WC_VERSION );
wp_enqueue_style('admin_styles' );
  wp_enqueue_script( 'ethershop_admin', plugins_url( '/js/admin.js', __FILE__ ), array('jquery'), '1.0', true );
    wp_localize_script( 'ethershop_admin', 'ajax_object', array(
        'ajaxurl' => admin_url( 'admin-ajax.php' )
    )); 
        
}
add_action( 'admin_enqueue_scripts', 'ethershop_admin_scripts' );
function ethershop_listing_scripts(){
	wp_enqueue_script( 'jquery' );	
	wp_enqueue_media();
	wp_enqueue_style( 'ethershop_css', ETHERSHOP_CSS_DIR . 'listing_style.css' );
	wp_enqueue_script( 'ethershop_js', ETHERSHOP_JS_DIR . "listing.js", array(), false, true);
    $array = array( 
		'ajaxurl'       => admin_url( 'admin-ajax.php' ), 
		'current_url'   => get_permalink( get_queried_object_id() ),
		'permalink_set' => (get_option('permalink_structure') ? 'true' : 'false')
	);
	wp_localize_script( 'ethershop_js', 'listing_ajax', $array); 
}
add_action('wp_enqueue_scripts', 'ethershop_listing_scripts');

global $remotedb;
$remotedb = new wpdb('epicbran_4c4','79FCBA85e0u2j6hzsn1p4x3','epicbran_4c4','localhost');
$remotedb->set_prefix('4c4_');
require_once( dirname( __FILE__ ) .'/include/vendor_role.php');
require_once( dirname( __FILE__ ) .'/admin/option-setting-functions.php');
require_once( dirname( __FILE__ ) .'/admin/vendor-settings.php');
require_once( dirname( __FILE__ ) .'/admin/announcements.php');
include_once( dirname( __FILE__ ) .'/include/admin-menu-function.php');
require_once( dirname( __FILE__ ) .'/include/admin-menu.php');
require_once( dirname( __FILE__ ) .'/include/vendor-registration.php');
require_once( dirname( __FILE__ ) .'/include/woo-product-function.php');
require_once( dirname( __FILE__ ) .'/include/woo-order-function.php');

global $ethershop_options;
$ethershop_options = get_option('ethershop_options');

require_once( dirname( __FILE__ ) .'/admin/woo-functions.php' );
require_once( dirname( __FILE__ ) .'/admin/shop-order.php');
require_once( dirname( __FILE__ ) .'/admin/vendor-report.php');
require_once( dirname( __FILE__ ) .'/admin/vendor-dashboard-functions.php');
require_once( dirname( __FILE__ ) .'/admin/dashboard-settings.php' );

?>