<?php
//    Option Settings From Admin Side
function setting_general(){
$registration_check = $tnc_check = $store_map_check = $store_form_check = '';

$setting_general = get_option('setting_general');
if(!empty($setting_general)){
$setting_general = maybe_unserialize($setting_general);
// echo "<pre>".print_r($setting_general, 1)."</pre>";
$registration = $setting_general['registration'];
if($registration == 1){
 $registration_check = 'checked';
}
$store_url = $setting_general['store_url'];
$tnc =  $setting_general['tnc'];
if($tnc == 1){
 $tnc_check = 'checked';
}
$fee_recipient = $setting_general['fee_recipient'];
$store_map =  $setting_general['store_map'];
if($store_map == 1){
 $store_map_check = 'checked';
}
$api_key = $setting_general['api_key'];
$store_form =  $setting_general['store_form'];
if($store_form == 1){
 $store_form_check = 'checked';
}
}
if(isset($_POST['save_setting_general'])){
$registration = isset($_POST['registration']) ? 1 : 0;
if($registration == 1){
 $registration_check = 'checked';
}
$store_url = $_POST['store_url'];
$tnc =  isset($_POST['tnc']) ? 1 : 0;
if($tnc == 1){
 $tnc_check = 'checked';
}
$fee_recipient = $_POST['fee_recipient'];

$store_map =  isset($_POST['store_map']) ? 1 : 0;
if($store_map == 1){
 $store_map_check = 'checked';
}
$api_key = $_POST['api_key'];
$store_form =  isset($_POST['store_form']) ? 1 : 0;
if($store_form == 1){
 $store_form_check = 'checked';
}
//echo $registration." ".$store_url." ".$tnc." ".$fee_recipient." ".$api_key;
$setting_general = array('registration' => $registration, 'store_url' => $store_url, 'tnc' => $tnc, 'fee_recipient' => $fee_recipient, 'store_map' => $store_map, 'api_key' => $api_key, 'store_form' => $store_form);
$setting_general = maybe_serialize($setting_general);
update_option('setting_general', $setting_general);
update_remote_option('setting_general', $setting_general);
}
?>
<h2>General Setting</h2>
<hr/>
<form id="setting_general" name="setting_general" method="post" action="<?php echo $_SERVER['REQUEST_URI'] ?>">
	<table border="0" cellspacing="0" cellpadding="0" class="widefat">
	<tr><td>Registration:</td><td><label><input name="registration" type="checkbox" id="registration" <?php echo $registration_check; ?> />Approve vendor applications manually</label></td></tr>
	 <tr><td>Vendor Store URL:</td><td><input name="store_url" type="text" id="store_url" value="<?php echo $store_url; ?>" /></td></tr>
	 <tr><td>Terms and Conditions:</td><td><label><input name="tnc" type="checkbox" id="tnc" <?php echo $tnc_check; ?> />Enable Terms and Conditions for vendor stores</label></td></tr>
	 <tr><td>Extra Fee Recipient:</td><td><select name="fee_recipient" ><option value="vendor">Vendor</option><option value="admin">Admin</option></select><div>Should extra fees, such as Shipping and Tax, go to the Vendor or the Admin?</div></td></tr>
	 <tr><td>Show Map on Store Page:</td><td><label><input name="store_map" type="checkbox" id="store_map"  <?php echo $store_map_check; ?> />Enable a Google Map of the Store Location in the store sidebar</label></td></tr>
	 <tr><td>Google Map API Key:</td><td><input name="api_key" type="text" id="api_key" value="<?php echo $api_key; ?>" /></td></tr>
	 <tr><td>Show Contact Form on Store Page:</td><td><label><input name="store_form" type="checkbox" id="store_form" <?php echo $store_form_check; ?> />Enable Vendor Contact Form in the store sidebar</label></td></tr>
	 <tr><td colspan="3"> &nbsp;&nbsp;&nbsp;&nbsp;<input name="save_setting_general" type="submit" class="button-secondary" value= "Save Unit"/></td></tr>
	</table>

</form>
<?php
}
function setting_product(){
$setting_product = get_option('setting_product');
if(!empty($setting_product)){
$setting_product = maybe_unserialize($setting_product);
// echo "<pre>".print_r($setting_general, 1)."</pre>";
$product_status = $setting_product['product_status'];
$button_text =  $setting_product['button_text'];

}
if(isset($_POST['save_setting_product'])){
$product_status = $_POST['product_status'];
$button_text = $_POST['button_text'];

//echo $registration." ".$store_url." ".$tnc." ".$fee_recipient." ".$api_key;
$setting_product = array('button_text' => $button_text, 'product_status' => $product_status);
$setting_product = maybe_serialize($setting_product);
update_option('setting_product', $setting_product);
update_remote_option('setting_product', $setting_product);
}
?>
<h2>Product Options</h2>
<hr/>
<form id="setting_product" name="setting_product" method="post" action="<?php echo $_SERVER['REQUEST_URI'] ?>">
<table border="0" cellspacing="0" cellpadding="0" class="widefat">
  <tr><td>New Product Status:</td><td><select name="product_status" ><option value="pending">Pending Review</option><option value="publish">Publish</option></select><div>Product status when vendor creates a product</div></td></tr>
  <tr><td>Sell Item Button Text:</td><td><input name="button_text" type="text" id="button_text" value="<?php echo $button_text; ?>" /><div>Change your sell this item button text</div></td></tr>
  <tr><td></td><td>&nbsp;&nbsp;&nbsp;&nbsp;<input name="save_setting_product" type="submit" class="btn button-primary" value= "Save Options"/></td></tr>
</table>

</form>
<?php
}

function selling_options(){
$vendor_product_upload_check = '';
$selling_options = get_option('selling_options');
if(!empty($selling_options)){
$selling_options = maybe_unserialize($selling_options);
// echo "<pre>".print_r($setting_general, 1)."</pre>";
$vendor_product_upload =  $selling_options['vendor_product_upload'];
if($vendor_product_upload == 1){
 $vendor_product_upload_check = 'checked';
}
$commission_type =  $selling_options['commission_type'];
$commission =  $selling_options['commission'];
}
if(isset($_POST['save_selling_options'])){
$vendor_product_upload =  isset($_POST['vendor_product_upload']) ? 1 : 0;
if($vendor_product_upload == 1){
 $vendor_product_upload_check = 'checked';
}
$commission_type = $_POST['commission_type'];
$commission = $_POST['commission'];
//echo $registration." ".$store_url." ".$tnc." ".$fee_recipient." ".$api_key;
$selling_options = array('vendor_product_upload' => $vendor_product_upload, 'commission_type' => $commission_type, 'commission' => $commission);
$selling_options = maybe_serialize($selling_options);
update_option('selling_options', $selling_options);
update_remote_option('selling_options', $selling_options);
}
?>
<h2>Selling Options</h2>
<hr/>
<form id="selling_options" name="selling_options" method="post" action="<?php echo $_SERVER['REQUEST_URI'] ?>">

	<table border="0" cellspacing="0" cellpadding="0" class="widefat">
<tr><td>New Vendor Product Upload:</td><td><label><input name="vendor_product_upload" type="checkbox" id="vendor_product_upload" <?php echo $vendor_product_upload_check; ?> />Allow newly registered vendors to add products</label></td></tr>
<tr><td>Commission Type:</td><td><select name="commission_type" ><option value="percentage">Percentage</option><option value="flat">Flat Fee</option></select><div><i>Select the commission type</i></div></td></tr>
<tr><td>Admin Commission:</td><td><input name="commission" type="text" id="commission" value="<?php echo $commission; ?>" /><div><i>Amount you get from sales</i></div></td></tr>
	 <tr><td colspan="3"> &nbsp;&nbsp;&nbsp;&nbsp;<input name="save_selling_options" type="submit" class="button-secondary" value= "Save Unit"/></td></tr>

	</table>

</form>
<?php
}

function withdraw_options(){
$paypal_check = $bank_transfer_check = '';
$withdraw_options = get_option('withdraw_options');
if(!empty($withdraw_options)){
$withdraw_options = maybe_unserialize($withdraw_options);
// echo "<pre>".print_r($setting_general, 1)."</pre>";
$paypal =  $withdraw_options['paypal'];
if($paypal == 1){
 $paypal_check = 'checked';
}
$bank_transfer =  $withdraw_options['bank_transfer'];
if($bank_transfer == 1){
 $bank_transfer_check = 'checked';
}
$withdraw_limit =  $withdraw_options['withdraw_limit'];
}
if(isset($_POST['save_withdraw_options'])){
$paypal =  isset($_POST['paypal']) ? 1 : 0;
if($paypal == 1){
 $paypal_check = 'checked';
}
$bank_transfer =  isset($_POST['bank_transfer']) ? 1 : 0;
if($bank_transfer == 1){
 $bank_transfer_check = 'checked';
}

$withdraw_limit = $_POST['withdraw_limit'];
//echo $registration." ".$store_url." ".$tnc." ".$fee_recipient." ".$api_key;
$withdraw_options = array('paypal' => $paypal, 'bank_transfer' => $bank_transfer, 'withdraw_limit' => $withdraw_limit);
$withdraw_options = maybe_serialize($withdraw_options);
update_option('withdraw_options', $withdraw_options);
update_remote_option('withdraw_options', $withdraw_options);
}
?>
<h2>Withdraw Options</h2>
<hr/>
<form id="withdraw_options" name="withdraw_options" method="post" action="<?php echo $_SERVER['REQUEST_URI'] ?>">
<table border="0" cellspacing="0" cellpadding="0" class="widefat">
<tr><td>Withdraw Methods:</td><td><label><input name="paypal" type="checkbox" id="paypal" <?php echo $paypal_check; ?> />PayPal</label>
<label><input name="bank_transfer" type="checkbox" id="bank_transfer" <?php echo $bank_transfer_check; ?> />Bank Transfer</label><div><i>Withdraw methods for vendors</i></div></td></tr>
<tr><td>Minimum Withdraw Limit:</td><td><input name="withdraw_limit" type="text" id="withdraw_limit" value="<?php echo $withdraw_limit; ?>" /><div><i>Minimum balance required to make a withdraw request. Leave blank to set no minimum limits.</i></div></td></tr>
<tr><td colspan="3"> &nbsp;&nbsp;&nbsp;&nbsp;<input name="save_withdraw_options" type="submit" class="btn button-primary" value= "Save Options"/></td></tr>
</table>

</form>
<?php
}

function update_remote_option($key, $value){
global $remotedb;
    $option_chk = $remotedb->get_var("SELECT option_id  FROM {$remotedb->options} WHERE option_name ='".$key."'");
 if(empty($option_chk)){
   $remotedb->insert($remotedb->prefix."options", array('option_name' => $key, 'option_value' => $value));
 }else{
   $remotedb->update($remotedb->prefix."options", array('option_value' => $value), array('option_name' => $key));
 }
}