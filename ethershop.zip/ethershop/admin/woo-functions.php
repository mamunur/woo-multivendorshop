<?php
function order_count_by_status($status, $vendor_id){
global $wpdb;
$order_count = $wpdb->get_var("SELECT COUNT(ID) as order_count FROM {$wpdb->posts}, {$wpdb->prefix}woocommerce_order_items, {$wpdb->prefix}woocommerce_order_itemmeta WHERE {$wpdb->posts}.post_status ='".$status."' AND {$wpdb->posts}.ID = {$wpdb->prefix}woocommerce_order_items.order_id AND {$wpdb->prefix}woocommerce_order_items.order_item_type = 'line_item' AND {$wpdb->prefix}woocommerce_order_items.order_item_id = {$wpdb->prefix}woocommerce_order_itemmeta.order_item_id AND {$wpdb->prefix}woocommerce_order_itemmeta.meta_key ='_product_id' AND {$wpdb->prefix}woocommerce_order_itemmeta.meta_value IN(Select ID from {$wpdb->posts} where post_author =$vendor_id)");

return $order_count;
}
function product_count_by_status($vendor_id){
global $wpdb;
    $query = "SELECT post_status, COUNT( * ) AS num_posts FROM {$wpdb->posts} WHERE post_type = 'product' AND post_status in ('publish','pending') AND post_author = $vendor_id ";
    
    $query .= ' GROUP BY post_status';
 
    $results = (array) $wpdb->get_results( $query, ARRAY_A );
    
    foreach ( $results as $row ) {
        $counts[ $row['post_status'] ] = $row['num_posts'];
    }
    return $counts;
}
function coupon_count_by_status($vendor_id){
global $wpdb;
    $query = "SELECT post_status, COUNT( * ) AS num_posts FROM {$wpdb->posts} WHERE post_type = 'shop_coupon' AND post_status in ('publish','pending') AND post_author = $vendor_id ";
    
    $query .= ' GROUP BY post_status';
 
    $results = (array) $wpdb->get_results( $query, ARRAY_A );
    
    foreach ( $results as $row ) {
        $counts[ $row['post_status'] ] = $row['num_posts'];
    }
    return $counts;
}
function admin_order_table_list(){
$url = admin_url('admin.php?page=shop_order');
$user = wp_get_current_user();
$user_id = ( isset( $user->ID ) ? (int) $user->ID : 0 );
if($_GET['action'] =="complete"){ 
  $status = array('wc-complete');
}elseif($_GET['action']== "processing") {
  $status = array('wc-processing');
}
 $order_count_completed = order_count_by_status('wc-completed', $user_id);
 $order_count_onhold =  order_count_by_status('wc-on-hold', $user_id);
 $order_count_processing =  order_count_by_status('wc-processing', $user_id);
 $order_count_pending = order_count_by_status('wc-pending', $user_id);
 $order_count_cancelled = order_count_by_status('wc-cancelled', $user_id);
 $order_count_refunded =  order_count_by_status('wc-refunded', $user_id);
if($_GET['order_status'] == "wc-completed"){ 
  $status = array('wc-completed');
}elseif($_GET['order_status'] == "wc-on-hold"){
  $status = array('wc-on-hold');
}elseif($_GET['order_status'] =="wc-processing"){
    $status = array('wc-processing');
}elseif($_GET['order_status'] =="wc-pending") {
    $status = array('wc-pending');   
}elseif($_GET['order_status'] == "wc-cancelled") {
    $status = array('wc-cancelled');
}elseif($_GET['order_status'] == "wc-refunded") {
    $status = array('wc-refunded');
}else{
  $status = array_keys( wc_get_order_statuses() );
}
//echo "<pre>".print_r($status, 1)."</pre>"; 
$customer_orders = get_posts( array(
        'numberposts' => -1,
        'post_type'   => 'shop_order',
        'post_status' => $status,
    ) );
//echo "<pre>".print_r($customer_orders, 1)."</pre>"; 
  ?>
<h1 class="wp-heading-inline">Orders</h1>
<a class="page-title-action" href="#">Add Order</a>
      <hr class="wp-header-end">
      <h2 class="screen-reader-text">Filter Order</h2>
      <ul class="subsubsub">
        <li class="all"><a class="current" aria-current="page" href="admin.php?page=shop_order">All <span class="count">(<?php echo $order_count; ?>)</span></a>|</li>
        <li class="wc-on-hold"><a href="admin.php?page=shop_order&order_status=wc-on-hold">On hold <span class="count">(<?php echo $order_count_onhold; ?>)</span></a>|</li>
        <li class="wc-completed"><a href="admin.php?page=shop_order&order_status=wc-completed">Completed <span class="count">(<?php echo $order_count_completed; ?>)</span></a></li>
      </ul>
      <table class="wp-list-table widefat fixed striped posts">
    <thead>
      <tr>
        <td id="cb" class="manage-column column-cb check-column"><label class="screen-reader-text" for="cb-select-all-1">Select All</label><input id="cb-select-all-1" type="checkbox"></input></td>
        <th scope="col" style="text-align:left;"><?php _e('Order', 'woothemes'); ?></th>
        <th scope="col" style="text-align:left;"><?php _e('Order Total', 'woothemes'); ?></th>
        <th id="order_status" class="manage-column column-order_status" scope="col" ><span class="status_head tips"><?php _e('Status', 'woothemes'); ?></span></th>
        <th scope="col" style="text-align:left;"><?php _e('Customer', 'woothemes'); ?></th>
        <th scope="col" style="text-align:left;"><?php _e('Date', 'woothemes'); ?></th>
        <th scope="col" style="text-align:left;"><?php _e('Action', 'woothemes'); ?></th>
      </tr>
    </thead>
    <tbody id="the-list">
      <?php // echo "<pre>".print_r($customer_orders, 1)."</pre>";
  foreach($customer_orders as $order):
    $order_id = $order->ID;
    $order = wc_get_order( $order_id );  
    $order_data = $order->get_data(); // The Order data
    $customer_name = $order_data['billing']['first_name']." ".$order_data['billing']['last_name'];
    $customer_email = $order_data['billing']['email'];
    foreach ($order->get_items() as $item_key => $item_values):
    $item_data = $item_values->get_data();
    $product_id = $item_data['product_id'];
    $vendor_id = get_post_field( 'post_author', $product_id );
    if($vendor_id == $user_id){
      $vendor_name = get_the_author_meta( 'display_name' , $vendor_id );
      echo '<tr><th class="check-column" scope="row">
      <label class="screen-reader-text" for="cb-select-'.$order_data["number"].'"></label>
       <input id="cb-select-'.$order_data["number"].'" type="checkbox" value="'.$order_data["number"].'" name="post[]"></input><div class="locked-indicator"></div>
</th><td>'.$order_data["number"].'
<div class="row-actions">
    <span class="edit"><a aria-label="Edit" href="'.$url.'&post='.$order_id.'&action=edit'.'">Edit</a>| 
    </span>
    <span class="trash"><a class="submitdelete" aria-label="Move "Order – December 20, 2017 @ 04:09 PM" to the Trash" href="/wp/wp-admin/post.php?post='.$order_id.'&action=trash&_wpnonce=33e261fe7d">Trash</a>
    </span>
</div>

</td><td>'.wc_price($item_data["total"]).'</td><td>'.$order_data["status"].'</td><td>'.$customer_name.'</td><td>'.$order_data['date_created']->date('d-m-Y h:i').'</td>
<td class="order_actions column-order_actions" data-colname="Actions">
<p>
    <a class="button tips shipped" href="#">Shipped</a>
    <a class="button tips view" href="'.$url.'&post='.$order_id.'&action=edit'.'">View</a>
</p>
</td></tr>';
//echo "<pre>".print_r($order_data, 1)."</pre>"; 
     }
    endforeach;
endforeach;
      ?>
  </tbody>
  <tfoot>
  </tfoot>
  </table>
<?php
}

function vendor_product_table_list(){
  $user = wp_get_current_user();
  $author_id = ( isset( $user->ID ) ? (int) $user->ID : 0 );
//echo $author_id;
//echo $user->roles[0];

$url = "admin.php"; 
if(isset($_GET['action']) && ($_GET['action']=='search')){
   echo $_GET['s'];
}
if(isset($_GET['product_status']) && ($_GET['product_status']=='publish')){
   $post_status = array('publish');
   $current_publish =  'class="current"'; 
   $current_pending ='';
   $current_all =  '';
}elseif(isset($_GET['product_status']) && ($_GET['product_status']=='pending')){
   $post_status = array('pending');
   $current_pending =  'class="current"'; 
   $current_publish ='';
   $current_all =  '';
}else{
   $post_status = array('publish', 'pending');
   $current_all =  'class="current"'; 
   $current_publish ='';
   $current_pending ='';
}
$product_count = product_count_by_status( $author_id);
$publish = $pending = $all = 0;
$publish = $product_count['publish'];
$pending = $product_count['pending'];
$all = $pending + $publish;
?>
<h1 class="wp-heading-inline">Products</h1>
<a class="page-title-action" href="post-new.php?post_type=product">Add New</a>
<a class="page-title-action" style="float:right;" href="edit.php?post_type=product&page=product_importer">Import</a>
<a class="page-title-action" style="float:right;" href="edit.php?post_type=product&page=product_exporter">Export</a>
      <hr class="wp-header-end">
      <h2 class="screen-reader-text">Filter Product</h2>
      <ul class="subsubsub">
        <li class="all"><a <?php echo $current_all; ?> aria-current="page" href="admin.php?page=vendor_product">All <span class="count">(<?php echo $all; ?>)</span></a>|</li>
        <li class="wc-publish"><a  <?php echo $current_publish; ?> href="admin.php?page=vendor_product&product_status=publish">Publish <span class="count">(<?php echo $publish; ?>)</span></a>|</li>
        <li class="wc-pending"><a  <?php echo $current_pending; ?> href="admin.php?page=vendor_product&product_status=pending">Pending <span class="count">(<?php echo $pending; ?>)</span></a></li>
      </ul>
<form id="product-filter" method="get" action="<?php echo $url; ?>" >
  <input type="hidden" name="page" value="vendor_product" />
  <input type="hidden" name="action" value="search">
  <p class="search-box">
    <label class="screen-reader-text" for="post-search-input">Search products:</label>
    <input id="post-search-input" name="s" value="" type="search" />
    <input id="search-submit" class="button" value="Search Products" type="submit" />
  </p>
<div class="tablenav top">
 <div class="alignleft actions">
  <select id="dropdown_product_type" name="product_type">
   <option value="">Filter by product type</option>
   <option value="simple">Simple</option>
   <option value="downlodable">->Downloadable</option>
   <option value="virtual">->Virtual</option>
  </select>
  <?php woo_product_dropdown(); ?>
 </div>
 <div class="tablenav-pages one-page">
  <span class="displaying-num"><?php echo $all; ?> items</span>
 </div>
</div>
<table class="wp-list-table widefat fixed striped posts">
  <thead>
    <tr><td id="cb" class="manage-column column-cb check-column"></td>
      <th id="thumb" class="manage-column column-thumb" scope="col"><span class="wc-image tips">Image</span></th>
      <th id="name" class="manage-column column-name column-primary sortable desc" scope="col" ><span>Name</span></th>
      <th id="sku" class="manage-column column-sku sortable desc" scope="col"><span>SKU</span></th>
      <th id="is_in_stock" class="manage-column column-is_in_stock" scope="col">Stock</th>
      <th id="price" class="manage-column column-price" scope="col">Price</th>
      <th id="featured" class="manage-column column-featured" scope="col" style="cursor:help;"><span class="wc-featured parent-tips" data-tip="Featured">Featured</span></th>
      <th id="product_type" class="manage-column column-product_type" scope="col"><span class="wc-type parent-tips" data-tip="Type">Type</span></th>
      <th id="product_status" class="manage-column column-product_status" scope="col"><span class="wc-status parent-tips" data-tip="Status">Status</span></th>
      <th id="views" class="manage-column column-views" scope="col">Views</th>
      <th id="date" class="manage-column column-date" scope="col">Date</th>
    </tr>
  </thead>
<?php

//echo "<pre>".print_r($product_count, 1)."</pre>"; 
$vendor_product = get_posts( array(
        'numberposts' => -1,
        'post_type'   => 'product',
        'author'      => $author_id,
        'post_status' => $post_status
    ) );
if(!empty($vendor_product)){
  foreach ($vendor_product as $value){
    $product_id = $value->ID;
    $product_status = $value->post_status;
    $post_date = date("d/M/Y",strtotime($value->post_date));
    $the_product = wc_get_product( $product_id );
    $thumbnail = '<a href="' . get_edit_post_link( $product_id ) . '">' . $the_product->get_image( 'thumbnail' ) . '</a>';
    $price = $the_product->get_price_html() ? $the_product->get_price_html() : '<span class="na">&ndash;</span>';

    $link = get_permalink( $the_product->get_id() );
    if ( current_user_can( 'delete_post', $product_id ) ) {
            if ( ! EMPTY_TRASH_DAYS ) {
              $delete_text = __( 'Delete permanently', 'woocommerce' );
            } else {
              $delete_text = __( 'Move to trash', 'woocommerce' );
            }
    $delete = '<a class="submitdelete deletion" href="'.esc_url( get_delete_post_link( $product_id ) ).'" >'.$delete_text.'</a>';         
  }
    $row_action = '<div class="row-actions"><a href="' . get_edit_post_link( $product_id ) . '">Edit</a> | '.$delete.' | <a href="'.$link.'">View</a></div>';
    $url = wp_nonce_url( admin_url( 'admin-ajax.php?action=woocommerce_feature_product&product_id=' . $product_id ), 'woocommerce-feature-product' );
                                 $featured = '<a href="' . esc_url( $url ) . '" aria-label="' . __( 'Toggle featured', 'woocommerce' ) . '">';
                                 if ( $the_product->is_featured() ) {
                                        $featured .= '<span class="wc-featured tips" data-tip="' . esc_attr__( 'Yes', 'woocommerce' ) . '">' . __( 'Yes', 'woocommerce' ) . '</span>';
                                 } else {
                                         $featured .= '<span class="wc-featured not-featured tips" data-tip="' . esc_attr__( 'No', 'woocommerce' ) . '">' . __( 'No', 'woocommerce' ) . '</span>';
                                 }
                                 $featured .= '</a>';
      if ( $the_product->is_in_stock() ) {
        $stock_html = '<mark class="instock">' . __( 'In stock', 'woocommerce' ) . '</mark>';
      } else {
        $stock_html = '<mark class="outofstock">' . __( 'Out of stock', 'woocommerce' ) . '</mark>';
      }
      if ( $the_product->managing_stock() ) {
        $stock_html .= ' (' . wc_stock_amount( $the_product->get_stock_quantity() ) . ')';
      }
    $admin_stock_html = apply_filters( 'woocommerce_admin_stock_html', $stock_html, $the_product );
    $sku = ($the_product->get_sku() ? esc_html( $the_product->get_sku() ) : '<span class="na">&ndash;</span>');
    if ( $the_product->is_type( 'grouped' ) ) {
        $product_type = '<span class="product-type tips grouped" data-tip="' . esc_attr__( 'Grouped', 'woocommerce' ) . '"></span>';
                                 } elseif ( $the_product->is_type( 'external' ) ) {
        $product_type = '<span class="product-type tips external" data-tip="' . esc_attr__( 'External/Affiliate', 'woocommerce' ) . '"></span>';
                                 } elseif ( $the_product->is_type( 'simple' ) ) {
 
                                         if ( $the_product->is_virtual() ) {
        $product_type = '<span class="product-type tips virtual" data-tip="' . esc_attr__( 'Virtual', 'woocommerce' ) . '"></span>';
                                         } elseif ( $the_product->is_downloadable() ) {
        $product_type = '<span class="product-type tips downloadable" data-tip="' . esc_attr__( 'Downloadable', 'woocommerce' ) . '"></span>';
                                         } else {
        $product_type = '<span class="product-type tips simple" data-tip="' . esc_attr__( 'Simple', 'woocommerce' ) . '"></span>';
                                         }
                                 } elseif ( $the_product->is_type( 'variable' ) ) {
        $product_type = '<span class="product-type tips variable" data-tip="' . esc_attr__( 'Variable', 'woocommerce' ) . '"></span>';
                                 } else {
                                         // Assuming that we have other types in future
        $product_type = '<span class="product-type tips ' . esc_attr( sanitize_html_class( $the_product->get_type() ) ) . '" data-tip="' . esc_attr( ucfirst( $the_product->get_type() ) ) . '"></span>';
  }
    echo '<tr><td ></td><td class="thumb column-thumb" data-colname="Image">' . wp_kses_post( $thumbnail ) . '</td>
    <td class="name column-name has-row-actions column-primary" data-colname="Name">'.$the_product->get_name().$row_action.'</td>
    <td>'. $sku . '</td>
    <td>'. $admin_stock_html. '</td>
    <td>'. $price.'</td><td>'. $featured.'</td>
    <td>'.$product_type.'</td><td>'.$product_status.'</td><td></td><td>'.$post_date.'</td></tr>';

  }
}
?>
</table>
</form>
<?php
}


function woo_product_dropdown(){
$args = array(
'taxonomy' => 'product_cat',
'orderby' => 'name',
'show_count' => 0,
'pad_counts' => 0,
'hierarchical' => 1,
'title_li' => '',
'hide_empty' => 0,
'parent' => 0
);
echo "<select name='product_name' >";
echo "<option value=''>Filter by product category</option>";
$all_categories = get_categories( $args );
foreach ($all_categories as $cat) :
   if($cat->category_parent == 0) {
        $category_id = $cat->term_id;       
        echo '<option value="'.$category_id.'">'. $cat->name .'</a>';
        $args2 = array(
                'taxonomy'     => 'product_cat',
                'parent'       => $category_id,
                'orderby'      => 'name',
                'show_count'   => 0,
                'pad_counts'   => 0,
                'hierarchical' => 1,
                'title_li'     => '',
                'hide_empty'   => 0
        );
        $sub_cats = get_categories( $args2 );
        if($sub_cats) {
            foreach($sub_cats as $sub_category) {
                echo '<option value="'.$sub_category->term_id.'">-'. $sub_category->name .'</a>';
            }   
        }
    }
endforeach; 
echo "</select>";
}

function vendor_coupon_table_list(){

  $user = wp_get_current_user();
  $author_id = ( isset( $user->ID ) ? (int) $user->ID : 0 );
//echo $author_id;
//echo $user->roles[0];
if(isset($_GET['coupon_status']) && ($_GET['coupon_status']=='publish')){
   $post_status = array('publish');
   $current_publish =  'class="current"'; 
   $current_pending ='';
   $current_all =  '';
}elseif(isset($_GET['coupon_status']) && ($_GET['coupon_status']=='pending')){
   $post_status = array('pending');
   $current_pending =  'class="current"'; 
   $current_publish ='';
   $current_all =  '';
}else{
   $post_status = array('publish', 'pending');
   $current_all =  'class="current"'; 
   $current_publish ='';
   $current_pending ='';
}
$product_count = coupon_count_by_status( $author_id);
$publish = $pending = $all = 0;
$publish = $product_count['publish'];
$pending = $product_count['pending'];
$all = $pending + $publish;
$url = "admin.php"; 

?>
<h1 class="wp-heading-inline">Coupons</h1>
<a class="page-title-action" href="post-new.php?post_type=shop_coupon">Add New Coupon</a>
      <hr class="wp-header-end">
      <h2 class="screen-reader-text">Filter Coupon</h2>
      <ul class="subsubsub">
        <li class="all"><a <?php echo $current_all; ?> aria-current="page" href="admin.php?page=vendor_coupon">All <span class="count">(<?php echo $all; ?>)</span></a>|</li>
        <li class="wc-publish"><a  <?php echo $current_publish; ?> href="admin.php?page=vendor_coupon&coupon_status=publish">Publish <span class="count">(<?php echo $publish; ?>)</span></a>|</li>
        <li class="wc-pending"><a  <?php echo $current_pending; ?> href="admin.php?page=vendor_coupon&coupon_status=pending">Pending <span class="count">(<?php echo $pending; ?>)</span></a></li>
      </ul>
<form id="coupon-filter" method="get" action="<?php echo $url; ?>" >
  <input type="hidden" name="page" value="vendor_product" />
  <input type="hidden" name="action" value="search">
  <p class="search-box">
    <label class="screen-reader-text" for="post-search-input">Search coupons:</label>
    <input id="post-search-input" name="s" value="" type="search" />
    <input id="search-submit" class="button" value="Search Products" type="submit" />
  </p>
<div class="tablenav top">
 <div class="alignleft actions">
  <select id="dropdown_product_type" name="product_type">
   <option value="">Filter by product type</option>
   <option value="simple">Simple</option>
   <option value="downlodable">->Downloadable</option>
   <option value="virtual">->Virtual</option>
  </select>
  <?php woo_product_dropdown(); ?>
 </div>
 <div class="tablenav-pages one-page">
  <span class="displaying-num"><?php echo $all; ?> items</span>
 </div>
</div>
<table class="wp-list-table widefat fixed striped posts">
  <thead>
    <tr><td id="cb" class="manage-column column-cb check-column"></td>
      <th id="coupon_code" class="manage-column column-coupon_code column-primary" scope="col"><?php _e( 'Code', 'woocommerce' ); ?></th>
      <th id="type" class="manage-column column-type sortable desc" scope="col" ><?php _e( 'Coupon type', 'woocommerce' ); ?></th>
      <th id="amount" class="manage-column column-amount sortable desc" scope="col"><?php _e( 'Coupon amount', 'woocommerce' ); ?></th>
      <th id="description" class="manage-column column-description" scope="col"><?php _e( 'Description', 'woocommerce' ); ?></th>
      <th id="status" class="manage-column column-status" scope="col"><?php _e( 'Status', 'woocommerce' ); ?></th>
      <th id="products" class="manage-column column-products" scope="col"><?php _e( 'Product IDs', 'woocommerce' ); ?></th>
      <th id="usage" class="manage-column column-usage" scope="col" style="cursor:help;"><?php _e( 'Usage / Limit', 'woocommerce' ); ?></th>
      <th id="expiry_date" class="manage-column column-expiry_date" scope="col"><?php _e( 'Expiry date', 'woocommerce' ); ?></th>
    </tr>
  </thead>
<?php

//echo "<pre>".print_r($product_count, 1)."</pre>"; 
$vendor_coupon = get_posts( array(
        'numberposts' => -1,
        'post_type'   => 'shop_coupon',
        'author'      => $author_id,
        'post_status' => $post_status
    ) );
if(!empty($vendor_coupon)){
  foreach ($vendor_coupon as $value){
    $coupon_id = $value->ID;
    $coupon_status = $value->post_status;
    $post_date = date("d/M/Y",strtotime($value->post_date));
    $the_coupon = new WC_Coupon( $value->ID );
    $edit_link = get_edit_post_link( $value->ID );
    $title     = $the_coupon->get_code();
    $coupon_title = '<strong><a class="row-title" href="' . esc_url( $edit_link ) . '">' . esc_html( $title ) . '</a></strong>';
    $type = esc_html( wc_get_coupon_type( $the_coupon->get_discount_type() ) );
    $amount = esc_html( wc_format_localized_price( $the_coupon->get_amount() ) );
    $product_ids = $the_coupon->get_product_ids();
    if ( sizeof( $product_ids ) > 0 ) {
      $productids = esc_html( implode( ', ', $product_ids ) );
    } else {
      $productids = '&ndash;';
    }
    $usage_count = $the_coupon->get_usage_count();
    $usage_limit = $the_coupon->get_usage_limit();
   /* translators: 1: count 2: limit */
    $usage = sprintf(
     __( '%1$s / %2$s', 'woocommerce' ),
      esc_html( $usage_count ),
       esc_html( $usage_limit ? $usage_limit : '&infin;' )
     );
    $expiry_date = $the_coupon->get_date_expires();
    if ( $expiry_date ) {
       $expirydate = esc_html( $expiry_date->date_i18n( 'F j, Y' ) );
    } else {
       $expirydate = '&ndash;';
    }
    $description = wp_kses_post( $the_coupon->get_description() ? $the_coupon->get_description() : '&ndash;' );
    echo '<tr><td ></td><td class="coupon_code column-coupon_code has-row-actions column-primary" data-colname="Code">' .$coupon_title . '</td>
    <td class="name column-name has-row-actions column-primary" data-colname="Name">'.$type.$row_action.'</td>
    <td>'. $amount . '</td><td>'.$description.'</td><td>'.$coupon_status.'</td>
    <td>'. $productids. '</td>
    <td>'. $usage.'</td><td>'. $expirydate.'</td></tr>';
  }// foreach
} // in
?>
</table>
</form>
<?php
}//function close
function vendors_report_list(){

  $user = wp_get_current_user();
  $author_id = ( isset( $user->ID ) ? (int) $user->ID : 0 );
//echo $author_id;
$url = "admin.php"; 

?>
<h1 class="wp-heading-inline">Reports</h1>

<?php
}//function close