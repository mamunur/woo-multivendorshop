<?php
function user_login_redirect( $redirect_to, $request, $user ) {
	//is there a user to check?
	if( isset( $user->roles ) && is_array( $user->roles ) ) {
		//check for admins
		if ( in_array( 'administrator', $user->roles ) || in_array( 'vendor', $user->roles ) ) {
			// redirect them to the default place
			return $redirect_to;
		} else {
			return home_url();
		}
	}else{
		return $redirect_to;
	}
}// function close

add_filter( 'login_redirect', 'user_login_redirect', 10, 3 );
add_action( 'admin_bar_menu', 'remove_wp_admin_nodes', 999 );
function remove_wp_admin_nodes() {
    global $wp_admin_bar;   
	global $current_user;
   if ( in_array( 'vendor', $current_user->roles ) ) {
    //The user has the "author" role
     $wp_admin_bar->remove_node( 'site-name' );
     $wp_admin_bar->remove_node( 'wp-logo' );
     $wp_admin_bar->remove_node( 'customize' );
	 $wp_admin_bar->remove_node( 'tc-customizr' );
	 $wp_admin_bar->remove_node( 'new-content' );
	 $wp_admin_bar->remove_node( 'comments' );
	 $wp_admin_bar->remove_node( 'laborator-options');
	 $wp_admin_bar->remove_node( 'wpseo-menu');
   }
}// function close 
add_action( 'admin_menu', 'remove_menus' );
function remove_menus(){
    global $current_user;
    // is there a user ?// substitute your role(s):
    if ( in_array( 'vendor', $current_user->roles ) ) {
     remove_menu_page( 'index.php' );
	 remove_menu_page('link-manager.php');
     remove_menu_page('tools.php');
	 remove_menu_page('plugins.php');
	 remove_menu_page('themes.php');
     remove_menu_page('users.php');
     remove_menu_page('edit-comments.php');  
	 remove_menu_page('edit.php');
	 remove_menu_page('edit.php?post_type=page'); 
	 remove_menu_page('edit.php?post_type=testimonial'); 
	 remove_menu_page('admin.php?page=vc-welcome'); 
	 remove_menu_page('edit.php?post_type=product'); 
	 remove_menu_page( 'upload.php' ); 
     remove_menu_page( 'options-general.php' );        //Settings
     remove_menu_page( 'woocommerce' ); // WooCommerce admin menu slug
    }
}

add_action('pre_get_posts', 'ether_pre_get_posts');
function ether_pre_get_posts($query) {
    if ($query->is_author() && $query->is_main_query()) {
        $query->set('post_type', 'product');
    }
}

add_action('init', 'ether_add_author_woocommerce', 999 );

function ether_add_author_woocommerce() {
   add_post_type_support( 'product', 'author' );
}

function published_to_pending( $post_id ) {
    global $post, $current_user, $wp_meta_boxes ;

    if ( !is_object( $post ) )
        $post = get_post( $post_id );
    if ( !current_user_can( 'edit_post', $post_id ) )
        return $post_id;
    // check for specific user that needs this publish to pending. otherwise exit
  if ( in_array( 'vendor', $current_user->roles ) ) {
    if ( ($post->post_status=="publish") && (($post->post_type == 'product') || ($post->post_type == 'shop_coupon'))) {
        global $wpdb;
        $result = $wpdb->update(
            $wpdb->posts,
            array( 'post_status' => "pending" ),
            array( 'ID' => $post_id )
        );
    }
  }
}
add_action( 'post_updated', 'published_to_pending', 13, 2 );
add_action('save_post','published_to_pending');

add_filter('wp_dropdown_users', 'custom_author_select');
function custom_author_select($output){
global $current_user;
if ( in_array( 'vendor', $current_user->roles ) ) {
    $output = "<select id=\"post_author_override\" name=\"post_author_override\" class=\"\">";
        $sel = "selected='selected'";
        $output .= '<option value="'.$current_user->ID.'"'.$sel.'>'.$current_user->first_name." ".$current_user->last_name."( ".$current_user->user_login." )".'</option>';
    $output .= "</select>";
}
    return $output;
}

add_action( 'show_user_profile', 'extra_user_profile_fields' );
add_action( 'edit_user_profile', 'extra_user_profile_fields' );

function extra_user_profile_fields( $user ) { ?>
    <h3><?php _e("Store information", "blank"); ?></h3>

    <table class="form-table">
	<tr><th><label for="address"><?php _e("Store name"); ?></label></th><td>
<input type="text" name="store_name" id="store_name" value="<?php echo esc_attr( get_the_author_meta( 'store_name', $user->ID ) ); ?>" class="regular-text" /><br />
<span class="description"><?php _e("Please enter your Store name."); ?></span>
    </td></tr>
    <tr><th><label for="address"><?php _e("Street"); ?></label></th>
        <td>
<input type="text" name="street" id="street" value="<?php echo esc_attr( get_the_author_meta( 'street', $user->ID ) ); ?>" class="regular-text" /><br />
<span class="street"><?php _e("Please enter street."); ?></span>
        </td>
    </tr>
    <tr>
        <th><label for="city"><?php _e("City"); ?></label></th>
        <td>
           <input type="text" name="city" id="city" value="<?php echo esc_attr( get_the_author_meta( 'city', $user->ID ) ); ?>" class="regular-text" /><br />
           <span class="description"><?php _e("Please enter your city."); ?></span>
        </td>
    </tr>
    <tr>
    <th><label for="postalcode"><?php _e("town"); ?></label></th>
        <td>
          <input type="text" name="town" id="town" value="<?php echo esc_attr( get_the_author_meta( 'town', $user->ID ) ); ?>" class="regular-text" /><br />
          <span class="description"><?php _e("Please enter your town."); ?></span>
        </td>
    </tr>
	<tr>
    <th><label for="zip"><?php _e("zip"); ?></label></th>
        <td>
           <input type="text" name="zip" id="zip" value="<?php echo esc_attr( get_the_author_meta( 'zip', $user->ID ) ); ?>" class="regular-text" /><br />
           <span class="description"><?php _e("Please enter zip code."); ?></span>
        </td>
    </tr>
	<tr>
    <th><label for="zip"><?php _e("Country"); ?></label></th>
        <td>
           <input type="text" name="country_field" id="country_field" value="<?php echo esc_attr( get_the_author_meta( 'country_field', $user->ID ) ); ?>" class="regular-text" /><br />
           <span class="description"><?php _e("Please enter country."); ?></span>
        </td>
    </tr>
    </table>
<?php }

function get_vendor_review_by_status(){
global $current_user, $wpdb;
$current_vendor = $current_user->ID;
$all_comments = get_comments( array('type' => '', 'number'=>'') );
  //echo "<pre>".print_r($all_comments, 1)."</pre>";
$pending = $approved = $spam = 0;
$result = array();
foreach($all_comments as $comment) {
$productid = $comment->comment_post_ID;
$vendor_id = get_post_field ('post_author', $productid);
if($vendor_id == $current_vendor):
	if($comment->comment_approved == 0){
	  $pending++;
	}
	if($comment->comment_approved == 1){
	  $approved++;
	}
	if($comment->comment_approved == 'spam'){
	  $spam++;
	}
endif;
}
$total = $pending + $approved + $spam;
$result['pending'] = $pending;
$result['approved'] = $approved;
$result['spam'] = $spam;
$result['total'] = $total;
return $result;
}// close