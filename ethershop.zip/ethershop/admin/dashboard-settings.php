<?php
add_action( 'admin_menu', 'ethershop_vendor_admin_menu' );
function ethershop_vendor_admin_menu() {
global $wpdb, $current_user;
if ( in_array( 'vendor', $current_user->roles ) ) {
	add_menu_page(
		__( 'EtherShop', 'ethershop' ),
		__( 'EtherShop', 'ethershop' ),
		'edit_posts',
		'vendor_dashboard',
		'vendor_dashboard_page',
		plugins_url( 'inventory_management/images/elite-icon-old.png' ),
		'7'
	);
add_submenu_page('vendor_dashboard', 'DashBoard', 'DashBoard', 'edit_posts', 'vendor_dashboard' );
//add_submenu_page( 'inventory_admin', 'Add New Item', "<i class='fa fa-folder-open'></i>All Item", 'manage_woocommerce', '', 'edit.php?post_type=shop_order');
//add_submenu_page( 'inventory_admin', __( 'Booking', 'woocommerce' ), __( 'Booking', 'woocommerce' ), 'manage_product_terms', 'edit.php?post_type=shop_order' );
add_submenu_page( 'vendor_dashboard', 'All Orders', "<i class='fa fa-folder-open'></i>Orders", 'edit_posts', 'shop_order', 'all_shop_order' );
add_submenu_page( 'vendor_dashboard', 'Add Products', "<i class='fa fa-folder-open'></i>Products", 'edit_posts', 'vendor_product', 'all_shop_product' );
//add_submenu_page( 'vendor_dashboard', 'Add Coupons', "<i class='fa fa-folder-open'></i>Coupons", 'edit_posts', 'vendor_coupon', 'all_shop_coupon' );
add_submenu_page( 'vendor_dashboard', 'Withdraw', "<i class='fa fa-folder-open'></i>Withdraw", 'edit_posts', 'vendor_withdraw', 'vendor_withdraw_pape' );
add_submenu_page( 'vendor_dashboard', 'Product Reviews', "<i class='fa fa-folder-open'></i>Product Reviews", 'edit_posts', 'vendor_reviews', 'vendor_reviews_pape' );
add_submenu_page( 'vendor_dashboard', 'Report Section', "<i class='fa fa-gears'></i> Reports", 'edit_posts', 'report_section','show_all_reports' );
add_submenu_page( 'vendor_dashboard', 'Options Setting', "<i class='fa fa-gears'></i> Options Settings", 'edit_posts', 'option_setting','vendor_setting_page' );
  add_menu_page(
	__( 'Logout', 'ethershop' ),
	__( 'Logout', 'ethershop' ),
	'edit_posts',
	'admin_logout',
	'inventory_logout_admin_page', 
	'dashicons-lock', 
	'10'
  );
}
}// function close

function menu_active_252428() {
global $parent_file, $post_type;
if ( $post_type == 'shop_order' ) {
    $parent_file = 'page';
}
}
add_action( 'admin_head', 'menu_active_252428' );

function vendor_dashboard_page() {
global $current_user;
$vendor_id = $current_user->ID;
include_once( dirname( __FILE__ ) . '/report-functions.php' );
?>
<div class="wrap">
<div id="dashboard-widgets-wrap">
<div id="postbox-container-1" class="postbox-container">
 <div id="dashboard_announcement" class="postbox vendor-block">
    <div class="inside">
      <div class="main">
	  <?php
	  $total_sales = ethershop_get_total_sales_by_vendor($vendor_id);
	  $order_items = ethershop_get_total_items_by_vendor($vendor_id);
	  $selling_options = get_option('selling_options');
	  $selling_options = maybe_unserialize($selling_options);
$commission_type =  $selling_options['commission_type'];
$commission =  $selling_options['commission'];

if($commission_type == 'percentage'){
  $calculate = ($selling_options['commission'] * $total_sales)/100;
  $earning = ($total_sales - $calculate);
}elseif($commission_type == 'flat'){
  $calculate = ($selling_options['commission'] * $order_items);
  $earning = ($total_sales - $calculate);
}
    $vendor_views_count = get_user_meta($vendor_id, 'vendor_views_count', true);
	  ?>
		<ul class="list-block">
		 <li><div class="title">Sales</div><div class="count"><?php echo wc_price($total_sales); ?></div></li>
		 <li><div class="title">Earning</div><div class="count"><?php echo wc_price($earning); ?></div></li>
		 <li><div class="title">PageView</div><div class="count"><?php echo $vendor_views_count; ?></div></li>
		 <li><div class="title">Items Sale</div><div class="count"><?php echo $order_items; ?></div></li>
		</ul>
	  </div>	
	</div>
   </div>
 </div>
<div id="postbox-container-2" class="postbox-container">
 <div id="dashboard_announcement" class="postbox vendor-block">
  <div class="widget-title"><i class="fa fa-bullhorn" ></i> Latest Announcement <span class="pull-right">See All</span></div>
    <div class="inside">
      <div class="main">
	  <?php
$args = array(
	'post_type' => 'announcement',
	'post_status' => 'publish',
	'numberposts' => 2,
	'orderby' => 'post_date',
	'order' => 'DESC',
);
$recent_posts = wp_get_recent_posts($args);
?>
		<ul class="list-inline">
<?php
	foreach( $recent_posts as $recent ){?>
		 <li><div class="announce-content"><div class="title"><a href="<?php echo get_permalink($recent["ID"]); ?>"><?php echo $recent["post_title"]; ?></a></div>
		 <div class="post-content"><?php echo wp_trim_words( $recent["post_content"], 10, '...' ); ?></div></div><div class="announce-date"><?php echo date('dS M Y',strtotime($recent["post_date"])); ?></div></li>
<?php }
	wp_reset_query();
	?>
		</ul>
	  </div>	
	</div>
   </div>
 </div>
  <div id="postbox-container-3" class="postbox-container">
   <div id="dashboard_order" class="postbox vendor-block">
   <div class="widget-title"><i class="fa fa-bullhorn" ></i> Reviews </div>
    <div class="inside">
      <div class="main">
	  <?php
	  $result = get_vendor_review_by_status();
	  $pending = $result['pending'];
      $approved = $result['approved'];
	  $spam  = $result['spam'];
	  $all  = $result['total'];
	  ?>
		<ul class="list-normal">
		 <li><div class="left-block">All</div><div class="right-block"><?php echo $all; ?></div></li>
		 <li><div class="left-block">Pending</div><div class="right-block"><?php echo $pending; ?></div></li>
		 <li><div class="left-block">Approved</div><div class="right-block"><?php echo $approved; ?></div></li>
		 <li><div class="left-block">Spam</div><div class="right-block"><?php echo $spam; ?></div></li>
		</ul>
	  </div><!--main-->	
	</div><!--inside-->
   </div><!--dashboard_order-->
 </div><!--postbox-container-3-->


</div><!--dashboard-widgets-wrap-->
</div><!--wrap-->
<?php
}//function close
function all_shop_order() { 
	$post_id = $_GET['post'];
?>
  <div class="wrap">
      <?php echo $url;
      if($_GET['action'] == "edit"){ 
        WC_Shop_Order_Data::output($post_id);
      }else{
      	admin_order_table_list();
      }
      ?>
  </div>
 <?php
}//function close
function all_shop_product() {
 ?>
  <div class="wrap">
      <?php vendor_product_table_list(); ?>
  </div>
 <?php
}//function close
function all_shop_coupon() {
global $pagenow;
	?>
  <div class="wrap">
      <?php vendor_coupon_table_list(); ?>
  </div>
 <?php
}//function close
function show_all_reports() {
global $pagenow;
	?>
  <div class="wrap">
      <?php WC_Shop_Report_Data::menu_options(); ?>
  </div>
 <?php
}//function close

function vendor_setting_page() {
?>
  <div class="wrap">
<?php
vendor_settings();
?>
  </div>
<?php
}
function vendor_withdraw_pape() {
global $current_user, $wpdb, $remotedb;
$mysqldate = date("Y-m-d H:i:s");
$vendor_id = $current_user->ID;
$vendor_email = $current_user->user_email;
$remote_vendor_id = $remotedb->get_var("SELECT ID FROM ".$remotedb->prefix."users WHERE user_email = '".$vendor_email."'");
$vendor_balance = get_user_meta($vendor_id, 'vendor_balance', true );

$string = get_woocommerce_currency();
$url = admin_url( 'admin.php?page=vendor_withdraw');
if(isset($_POST['submit-request'])){
   $amount = $_POST['amount'];
   $method = $_POST['method'];
   if(amount > $vendor_balance){
     echo "<p>You don't have enough balance for this request</p>";
   }else{
     echo "<p>Your request has been received successfully and being reviewed!</p>";
	 $wpdb->insert($wpdb->prefix."withdraw",array('user_id' => $vendor_id, 'amount' => $amount, 'method' => $method, 'status' => 'pending', 'wdate' => $mysqldate));
	 $remotedb->insert($wpdb->prefix."withdraw",array('user_id' => $remote_vendor_id, 'amount' => $amount, 'method' => $method, 'status' => 'pending', 'wdate' => $mysqldate));
	 $vendor_balance = $vendor_balance - $amount;
	 update_user_meta($vendor_id, 'vendor_balance', $vendor_balance );
	 $remotedb->update($remotedb->prefix."usermeta", array('meta_key' => 'vendor_balance', 'meta_value' => $vendor_balance), array('user_id' => $remote_vendor_id));
   }
}
if(isset($_POST['request-cancel'])){
  $cancel_id = $_POST['cancel_id'];
  $row = $wpdb->update($wpdb->prefix."withdraw", array('status' => 'cancelled'), array('id' => $cancel_id));
  $remotedb->update($remotedb->prefix."withdraw", array('status' => 'cancelled'), array('id' => $cancel_id));
}
?>
  <div class="wrap">
  <?php if(($_GET['type'] == 'withdraw') || ($_GET['type'] == '')){ ?>
     <p>Current Balance: <b><?php echo $string.$vendor_balance; ?></b></p>
     <p>Minimum Withdraw Amount: <b><?php echo $string; ?>50.00</b></p>
  <?php } ?>
   <ul class="withdraw-sub_menu"><li><a href="<?php echo $url; ?>&type=withdraw">Withdraw Request</a></li> | <li><a href="<?php echo $url; ?>&type=approved">Approved Requests</a></li> | <li><a href="<?php echo $url; ?>&type=cancelled">Cancelled Requests</a></li></ul>

    <?php if(($_GET['type'] == 'withdraw') || ($_GET['type'] == '')){
	$row = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."withdraw WHERE status = 'pending' AND user_id = ".$vendor_id, ARRAY_A); 
	if($row['status'] == 'pending'){ ?>
	<table class="widefat"> 
	<tr><td>Amount</td><td>Method</td><td>Date</td><td>Cancel</td><td>Status</td></tr>
	<tr><td><?php echo $row['amount']; ?></td><td><?php echo $row['method']; ?></td><td><?php echo $row['wdate']; ?></td><td><form name="request_cancel" method="post"><input type="hidden" name="cancel_id" value="<?php echo $row['id']; ?>" /><input type="submit" id="<?php echo $row['id']; ?>"  name="request-cancel" value="Cancel" class="request-cancel" /></form></td><td><?php echo $row['status']; ?></td>
	</table>
	<?php }else{ ?>
	<form name="submit_request" method="post">
	<table class="widefat">
	<tr><td>Withdraw Amount</td><td><?php echo $string; ?><input type="text" name="amount" class="amount"  /></td></tr>
	<tr><td>Payment Method</td><td>
	<select name="method" class="method" >
	  <option value="paypal" >PayPal</option>
	</select></td></tr>
	<tr><td></td><td><input type="submit" name="submit-request" value="Submit Request" /></td></tr>
	</table>
	</form>
	<?php } ?>
	<?php }elseif($_GET['type'] == 'approved'){ ?>
	<?php $row = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."withdraw WHERE status = 'approved' AND user_id = ".$vendor_id, ARRAY_A);
	?>
	<table class="widefat">
	<tr><td>Amount</td><td>Method</td><td>Date</td><td>Status</td></tr>
	<tr><td><?php echo $row['amount']; ?></td><td><?php echo $row['method']; ?></td><td><?php echo $row['wdate']; ?></td><td><?php echo $row['status']; ?></td></tr>
	</table>
	<?php }elseif($_GET['type'] == 'cancelled'){ ?>
	<?php $row = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."withdraw WHERE status = 'cancelled' AND user_id = ".$vendor_id, ARRAY_A);
	?>
	<table class="widefat">
	<tr><td>Amount</td><td>Method</td><td>Date</td><td>Status</td></tr>
	<tr><td><?php echo $row['amount']; ?></td><td><?php echo $row['method']; ?></td><td><?php echo $row['wdate']; ?></td><td><?php echo $row['status']; ?></td></tr>
	</table>
	<?php } ?>
   </div>
<?php
}//function close

function vendor_reviews_pape() {
global $current_user, $wpdb;
$current_vendor = $current_user->ID;
  $all_comments = get_comments( array('type' => '', 'number'=>'') );
  //echo "<pre>".print_r($all_comments, 1)."</pre>";
?>
<table class="vendor widefat">
<tr><th>Vendor</th><th>Product</th><th>Customer</th><th>Comments</th><th>Rating</th><th>Date</th></tr>
<?php foreach($all_comments as $comment) {
$productid = $comment->comment_post_ID;
$vendor_id = $author_id = get_post_field ('post_author', $productid);
if($vendor_id == $current_vendor):
$title = get_the_title($productid);
$user_id = $comment->user_id;
$display_name = get_the_author_meta( 'display_name' , $vendor_id );
$producturl = get_edit_post_link( $productid );
$vendorurl = admin_url('user-edit.php?user_id='.$vendor_id);
$rate = get_comment_meta( $comment->comment_ID, 'rating', true );
$args = array(
   'rating' => $rate,
   'type' => 'rating',
   'number' => 1,
   );
?>
<tr><td><a href="<?php echo $vendorurl; ?>" ><?php echo $display_name; ?></a>
<?php echo $row_actions; ?></td><td><a href="<?php echo $producturl; ?>" ><?php echo $title; ?></a></td><td><?php echo $comment->comment_author; ?></td><td><?php echo $comment->comment_content; ?></td><td><?php wp_star_rating($args); ?></td><td><?php echo $comment->comment_date; ?></td></tr>
<?php 
endif;
} ?>
</table>
<?php
}//function close
