<?php
function announcement_custom_post_type() {
// preparing parameters
$params = array(
  'labels' => array(
	  'name' => __('Announcements'),
	  'singular_name' => __('Announcement'),
	  'all_items'			=> __('Announcements', 'ethershop'),
	  'add_new' 			=> _x('Add new Announcement', 'Announcements'),
	  'add_new_item' 		=> __('Add new Announcement'),
	  'edit_item'			=> __('Edit Announcement'),
	  'new_item' 			=> __('New Announcement'),
	  'search_items'		=> __('Search Announcements', 'ethershop'),
	  'not_found'          	=> __('No Announcements found', 'ethershop'),
	  'not_found_in_trash' 	=> __('No Announcements found in Trash',  'ethershop'),
	  'menu_name'			=> __('Announcements', 'ethershop')
	),
	  'public'              => true,
	  'hierachical' => true,
	  'show_ui'            	=> true, 
	  'show_in_menu' 	    => false,
	  'menu_position'       => 4,
	  'has_archive'         => false,
	  'capability_type'    	=> 'post',
	  'publicly_queryable'  => true,
	  'rewrite'             => array( 'slug'=>'announcement','with_front'=> true,'page' => true,'feeds'=> true  ),
	  'exclude_from_search' => false,
	  'supports'			=> array('title', 'editor' )
);

// registering the post type
register_post_type('announcement', $params);
}

add_action('init', 'announcement_custom_post_type');
function plugin_add_custom_boxes($post_type){
  if ( in_array( $post_type, array( 'announcement' ) ) ) {
	add_meta_box( "announcement_settings", __("Announcement Settings", "ethershop"), "settings_tab", "announcement", "test", "high");
  }
}
function settings_tab(){ 
 global $post; 
 $quotation_info = get_post_meta($post->ID, "quotation_info", true);
 $quotation_info = json_decode($quotation_info,true);
 //echo "<pre>".print_r($quotation_info, 1)."</pre>";
 ?>
 <div id="settings_tab" >
   <table border='0' width="100%">
	<tr><td width="50%" class="border-right"> 
	<?php _e("Send Announcement To", "vehicle"); ?>
	</td><td> 
      <select name="announcement_setting">
	    <option value="all">All Vendor</option>
	  </select>
	</td></tr>
   </table>
 </div>
<?php 	
}
add_action( 'add_meta_boxes', 'plugin_add_custom_boxes' );
function move_custom_boxes() {
        # Get the globals:
        global $post, $wp_meta_boxes;
        # Output the "advanced" meta boxes:
        do_meta_boxes( get_current_screen(), 'test', $post );
        # Remove the initial "advanced" meta boxes:
        unset($wp_meta_boxes['announcement']['test']);
    }

add_action('edit_form_after_title', 'move_custom_boxes');

add_action('save_post', 'ethershop_announcement_post_save', 10, 2);

function ethershop_announcement_post_save($post_id, $post) {
 $announcement_setting = $_POST['announcement_setting'];
 if($post->post_type == 'announcement'){
  update_post_meta($post_id, 'announcement_setting', $announcement_setting);
 }
}