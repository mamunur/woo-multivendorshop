<?php
/**
 * Order Data
 *
 * Functions for displaying the order data meta box.
 *
 * @author    WooThemes
 * @category  Admin
 * @package   WooCommerce/Admin/Meta Boxes
 * @version     2.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

/**
 * WC_Meta_Box_Order_Data Class.
 */
class WC_Shop_Report_Data {

  /**
   * Billing fields.
   *
   * @var array
   */

  public static function init_file() {
    include_once( dirname( __FILE__ ) . '/report-functions.php' );
    
  }
  /**
   * Init billing and shipping fields we display + save.
   */
public static  function menu_options(){
 self::init_file();
 $tab = isset( $_GET['tab'] ) ? $_GET['tab'] : 'general';
 $set_menu_1 = ( $tab === "general" || $tab === "" ) ? "nav-tab nav-tab-active" : "nav-tab";
 $set_menu_2 = ( $tab === "sales_by_day" ) ? "nav-tab nav-tab-active" : "nav-tab";
 $set_menu_3 = ( $tab === "top_selling" ) ? "nav-tab nav-tab-active" : "nav-tab";
 $set_menu_4 = ( $tab === "top_earning" ) ? "nav-tab nav-tab-active" : "nav-tab";
 $set_menu_5 = ( $tab === "statement" ) ? "nav-tab nav-tab-active" : "nav-tab";
 $site = 'admin.php?page=report_section';
 $user = wp_get_current_user();
 $author_id = ( isset( $user->ID ) ? (int) $user->ID : 0 );
?>

<div class="wrap woocommerce">
 <h3 class="nav-tab-wrapper"><?php 
    echo '<a href="' . $site . '&amp;tab=general" class="' . $set_menu_1 . '" title="' . __('Overview','ethershop') . '" >' . __('Overview','ethershop') . '</a>';
    echo '<a href="' . $site . '&amp;tab=sales_by_day" class="' . $set_menu_2 . '" title="' . __('Sales by day','ethershop') . '">' . __('Sales by day','ethershop') . '</a>';
    echo '<a href="' . $site . '&amp;tab=top_selling" class="' . $set_menu_3 . '" title="' . __('Top Selling','ethershop') . '">' . __('Top Selling','ethershop') . '</a>'; 
    echo '<a href="' . $site . '&amp;tab=top_earning" class="' . $set_menu_4 . '" title="' . __('Top Earning','ethershop') . '">' . __('Top Earning','ethershop') . '</a>'; 
    echo '<a href="' . $site . '&amp;tab=statement" class="' . $set_menu_5 . '" title="' . __('Statement','ethershop') . '">' . __('Statement','ethershop') . '</a>'; 
  ?></h3>
  <div id="poststuff" class="woocommerce-reports-wide">
  <div class="postbox">
  <?php
  if ($tab == '' || $tab == 'general') {
  ?>
    <div class="inside chart-with-sidebar">
     <?php self::overview_report($author_id); ?>
    </div>
  <?php
  }elseif ( $tab === 'sales_by_day' ) { ?>
    <div class="inside chart-with-sidebar">
    <?php self::sales_by_day(); ?>
  </div>
  <?php 
  }elseif ( $tab === 'top_selling' ) { ?>
    <div class="inside chart-with-sidebar">
    <?php self::top_selling(); ?>
  </div>
  <?php 
  }elseif ( $tab === 'top_earning' ) { ?>
    <div class="inside chart-with-sidebar">
    <?php self::top_earning(); ?>
  </div>
  <?php 
  }elseif ( $tab === 'statement' ) { ?>
    <div class="inside chart-with-sidebar">
    <?php self::statement(); ?>
  </div>
  <?php 
  } ?>
   </div> <!--class="postbox"-->
  </div><!-- id="poststuff" -->
</div><!--class="wrap woocommerce"-->
<?php
}// function close
public static  function overview_report($author_id){
  $total_sales = ethershop_get_total_sales_by_vendor($author_id);
  $total_order = ethershop_get_total_order_by_vendor($author_id);
  $item_sold_total = ethershop_get_total_items_by_vendor($author_id);
  $coupon_usage = ethershop_get_coupon_usage_by_vendor($author_id);
  $total_shipping = ethershop_get_total_shipping_by_vendor($author_id);
  $net_sales = $total_sales  +  $total_shipping;
?>  
  <div class="chart-sidebar">
   <ul class="chart-legend">
     <li class="highlight_series tips">
       <strong><?php echo wc_price($total_sales); ?></strong>
       gross sales in this period
     </li>
     <li class="highlight_series tips">
       <strong><?php echo wc_price($net_sales); ?></strong>
        net sales in this period        
     </li>
     <li class="highlight_series tips">
       <strong><?php echo $total_order; ?></strong>
       orders placed
     </li>
     <li class="highlight_series tips">
       <strong><?php echo $item_sold_total; ?></strong>
        items purchased       
     </li>
     <li class="highlight_series tips">
       <strong><?php echo wc_price($total_shipping); ?></strong>
       charged of shipping
     </li>
     <li class="highlight_series tips">
       <strong><?php echo wc_price($coupon_usage); ?></strong>
        worth of coupon used        
     </li>
   </ul> 
  </div>
  <div class="main">
  <?php
    echo "Overview";
  ?>
  </div>
<?php
}//function close
public static  function sales_by_day(){
?>
  <div class="chart-sidebar">

  </div>
  <div class="main">
  <?php
    echo "Overview";
  ?>
  </div>
<?php
}//function close
public static  function top_selling(){
?>
  <div class="chart-sidebar">

  </div>
  <div class="main">
  <?php
    echo "Overview";
  ?>
  </div>
<?php
}//function close
public static  function top_earning(){
  ?>
  <div class="chart-sidebar">

  </div>
  <div class="main">
  <?php
    echo "Overview";
  ?>
  </div>
<?php
}//function close
public static  function statement(){
  ?>
  <div class="chart-sidebar">

  </div>
  <div class="main">
  <?php
    echo "Overview";
  ?>
  </div>
<?php
}//function close
}
