<?php
function vendor_settings(){
global $current_user, $remotedb;
$user_id = $current_user->ID;
$vendor_email = $current_user->user_email;
$remote_vendor_id = $remotedb->get_var("SELECT ID FROM ".$remotedb->prefix."users WHERE user_email = '".$vendor_email."'");
   $profile_picture = get_the_author_meta('profile_picture', $user_id );
   $store_banner = get_the_author_meta('store_banner', $user_id );
   $paypal_email = get_the_author_meta('paypal_email', $user_id );
   $store_name = get_the_author_meta('store_name', $user_id );
   $product_per_page = get_the_author_meta('product_per_page', $user_id );
   $street = get_the_author_meta('street', $user_id );
   $city = get_the_author_meta('city', $user_id );
   $town = get_the_author_meta('town', $user_id );
   $zip = get_the_author_meta('zip', $user_id );
   $country = get_the_author_meta('country_field', $user_id );
   $phone_no = get_the_author_meta('phone_no', $user_id );

if(isset($_POST['save_store'])){
$POST = array_map( 'stripslashes_deep', $_POST);
  $profile_picture = $POST['profile_picture'];
if(isset($POST['remote_profile_picture']) && !empty($POST['remote_profile_picture'])){
 $remote_profile_picture = $POST['remote_profile_picture'];
 $remote_thumbnail_id = remote_vendor_profile_image($remote_vendor_id, $remote_profile_picture);
}else{
 $remote_thumbnail_id = get_remote_thumbnail_id($remote_vendor_id, 'profile_picture');
}
if(isset($POST['remote_store_banner']) && !empty($POST['remote_store_banner'])){
 $remote_store_banner = $POST['remote_store_banner'];
 $remote_store_banner = remote_vendor_profile_image($remote_vendor_id, $remote_store_banner);
}else{
 $remote_store_banner = get_remote_thumbnail_id($remote_vendor_id, 'store_banner');

}
  $store_banner = $POST['store_banner'];
  $paypal_email = $POST['paypal_email'];
  $store_name = $POST['store_name'];
  $product_per_page  = $POST['product_per_page'];
  $street = $POST['street'];
  $city = $POST['city'];
  $town = $POST['town'];
  $zip = $POST['zip'];
  $phone_no = $POST['phone_no'];
  $country = $POST['country_field'];
    update_user_meta( $user_id, 'profile_picture', $profile_picture );
    update_user_meta( $user_id, 'store_banner', $store_banner );
    update_user_meta( $user_id, 'store_name', $store_name );
	update_user_meta( $user_id, 'paypal_email', $paypal_email );
	update_user_meta( $user_id, 'product_per_page', $product_per_page );
	update_user_meta( $user_id, 'street', $street );
    update_user_meta( $user_id, 'city', $city );
    update_user_meta( $user_id, 'town', $town );
	update_user_meta( $user_id, 'zip', $zip );
    update_user_meta( $user_id, 'country_field', $country );
	update_user_meta( $user_id, 'phone_no', $phone_no );
//echo $remote_profile_picture." ".$remote_thumbnail_id." ".$country." ".$remote_vendor_id;
save_remote_user_meta($remote_vendor_id, 'profile_picture', $remote_thumbnail_id);
save_remote_user_meta($remote_vendor_id, 'store_banner', $remote_store_banner);
save_remote_user_meta($remote_vendor_id, 'store_name', $store_name);
save_remote_user_meta($remote_vendor_id, 'paypal_email', $paypal_email);
save_remote_user_meta($remote_vendor_id, 'product_per_page', $product_per_page);
save_remote_user_meta($remote_vendor_id, 'street', $street);
save_remote_user_meta($remote_vendor_id, 'city', $city);
save_remote_user_meta($remote_vendor_id, 'town', $town);
save_remote_user_meta($remote_vendor_id, 'zip', $zip);
save_remote_user_meta($remote_vendor_id, 'country_field', $country);
save_remote_user_meta($remote_vendor_id, 'phone_no', $phone_no);

}
?>
<h2>General Setting</h2>
<hr/>
<form id="vendor_settings" name="vendor_settings" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>" >
<table border="0" cellspacing="0" cellpadding="0" class="widefat">
<tr><td><p><b><?php _e("PayPal Email:", "ethershop"); ?></b></p></td><td><input type="text" class="paypal_email" name="paypal_email" value="<?php echo trim($paypal_email); ?>" /></td></tr>
<tr><td><p><b><?php _e("Store Banner:", "ethershop"); ?></b></p></td><td><div class='store_banner_area'>
<?php
  if(isset($store_banner) && !empty($store_banner)){
	$full   = wp_get_attachment_image_src($store_banner, "full");
	$medium = wp_get_attachment_image_src($store_banner, "medium");
    echo "<a href='".$full[0]."' target='_blank'><img src='".$medium[0]."' style='width:100%;margin-top:8px;'></a>";
  }
?>
 </div>   
    <button class="store_banner button button-primary" data-uploader-title="<?php _e("Select a store banner", "ethershop"); ?>" data-uploader-button-text="<?php _e("Store Banner", "ethershop"); ?>" id="store_banner" >Banner Upload</button>
    <input type="hidden" class="store_banner_input" name="store_banner" value="<?php echo trim($store_banner); ?>" <?php echo (isset($store_banner) && !empty($store_banner) ? "data-id='" . auto_image_id($store_banner) . "'" : ""); ?> >
	<input type="hidden" class="remote_store_banner_input" name="remote_store_banner" value="<?php echo trim($remote_store_banner); ?>" <?php echo (isset($remote_store_banner) && !empty($remote_store_banner) ? "data-id='" .remote_auto_image_id($remote_store_banner)."'" : ""); ?> >
</td></tr>
  <tr><td><p><b><?php _e("Profile Picture:", "ethershop"); ?></b></p></td><td> 
   <div class='profile_picture_area'>
<?php
  if(isset($profile_picture) && !empty($profile_picture)){
    $full = wp_get_attachment_image_src($profile_picture, "full");
	$medium = wp_get_attachment_image_src($profile_picture, "medium");
    echo "<a href='".$full[0]."' target='_blank'><img src='".$medium[0]."' style='width:100%;margin-top:8px;'></a>";
  }
?>
 </div>   
    <button class="profile_picture button button-primary" data-uploader-title="<?php _e("Select a profile picture", "ethershop"); ?>" data-uploader-button-text="<?php _e("Select Photograph", "ethershop"); ?>" id="profile_picture" >Photograph Upload</button>
    <input type="hidden" class="profile_picture_input" name="profile_picture" value="<?php echo trim($profile_picture); ?>" <?php echo (isset($profile_picture) && !empty($profile_picture) ? "data-id='".auto_image_id($profile_picture)."'" : ""); ?> >
	<input type="text" class="remote_profile_picture_input" name="remote_profile_picture" value="<?php echo trim($remote_profile_picture); ?>" <?php echo (isset($remote_profile_picture) && !empty($remote_profile_picture) ? "data-id='".remote_auto_image_id($remote_profile_picture)."'" : ""); ?> >
</td></tr>
<tr><td><p><b><?php _e("Store Name:", "ethershop"); ?></b></p></td><td><input type="text" class="store_name" name="store_name" value="<?php echo trim($store_name); ?>" /></td></tr>
<tr><td><p><b><?php _e("Store Product Per Page:", "ethershop"); ?></b></p></td><td><input type="text" class="product_per_page" name="product_per_page" value="<?php echo trim($product_per_page); ?>" /></td></tr>
<tr><td><p><b><?php _e("Address:", "ethershop"); ?></b></p></td><td><input type="text" class="street" name="street" value="<?php echo trim($street); ?>" placeholder="Street" /><input type="text" class="city" name="city" value="<?php echo trim($city); ?>" placeholder="City" /><input type="text" class="town" name="town" value="<?php echo trim($town); ?>" placeholder="Town" /><input type="text" class="zip" name="zip" value="<?php echo trim($zip); ?>" placeholder="Zip Code" /><?php $countries_obj = new WC_Countries();
    $countries   = $countries_obj->__get('countries');
    echo '<div id="custom_countries_field">';
	  woocommerce_form_field('country_field', array(
		'type'       => 'select',
		'class'      => array( 'chzn-drop' ),
		'placeholder'    => __('Enter something'),
		'options'    => $countries
	  )
    );
    echo '</div>';
	?></td></tr>
	<tr><td><p><b><?php _e("Phone No:", "ethershop"); ?></b></p></td><td><input type="text" class="phone_no" name="phone_no" value="<?php echo trim($phone_no); ?>" placeholder="Phone No" /></td></tr>
	 <tr><td colspan="3">&nbsp;&nbsp;&nbsp;&nbsp;<input name="save_store" type="submit" class="button-secondary" value= "Save Store Info" /></td></tr>
	</table>
</form>
<?php
}
if(!function_exists("auto_image_id")){
    function auto_image_id($image_url){
        global $wpdb;
        $attachment = $wpdb->get_col($wpdb->prepare("SELECT ID FROM $wpdb->posts WHERE guid='%s';", $image_url )); 
        
        return (isset($attachment[0]) && !empty($attachment[0]) ? $attachment[0] : "");
    }
}

function remote_vendor_profile_image($vendor_id, $image_url){
global $wpdb, $remotedb;
$rupload_path =  "/home7/epicbran/public_html/moderntimbercraft/wp-content/uploads/2018/03/";
$rbaseurl =  "https://www.moderntimbercraft.com/wp-content/uploads/2018/03/";

$mysqldate = date("Y-m-d H:i:s");
$fname = basename($image_url);
$subdir_file = '2018/03/'.$fname;
$post_name = sanitize_title($fname);
$rurl = $rbaseurl.$fname;

 if(is_writable($rupload_path)) {
    file_put_contents($rupload_path.$fname, file_get_contents($image_url));
 }
$remote_thumbnail_id = $remotedb->get_var("SELECT ID from ".$remotedb->prefix."posts WHERE post_type = 'attachment' AND  post_name = '".$post_name."' AND post_author =".$vendor_id);
if(empty($remote_thumbnail_id)){
$remotedb->insert($remotedb->prefix.'posts', array('post_author' => $vendor_id, 'post_date' => $mysqldate, 'post_date_gmt' => $mysqldate, 'post_content' => '', 'post_title' => $fname, 'post_status' => 'inherit', 'post_name' => $post_name, 'post_parent' => 0, 'guid' => $rurl, 'post_type' => 'attachment', 'post_mime_type' => 'image/jpeg'));
$remote_thumbnail_id = $remotedb->insert_id;
$attachment_metadata = wp_get_attachment_metadata( $remote_thumbnail_id );
$attachment_metadata['file'] = $subdir_file;
$serialize_metadata = maybe_serialize($attachment_metadata);
$remotedb->insert($remotedb->prefix.'postmeta', array('post_id' => $remote_thumbnail_id, 'meta_key' => '_wp_attached_file', 'meta_value' => $subdir_file ));
$remotedb->insert($remotedb->prefix.'postmeta', array('post_id' => $remote_thumbnail_id, 'meta_key' => '_wp_attachment_metadata', 'meta_value' => $serialize_metadata ));
$remotedb->insert($remotedb->prefix.'postmeta', array('post_id' => 0, 'meta_key' => '_thumbnail_id', 'meta_value' => $remote_thumbnail_id ));
}else{
$remotedb->update($remotedb->prefix.'posts', array('guid' => $rurl), array('post_type' =>  'attachment', 'ID' => $remote_thumbnail_id));
}
return $remote_thumbnail_id;
}// function
function get_remote_thumbnail_id($remote_vendor_id, $meta_key){
global $remotedb;
  $old_meta_value = $remotedb->get_var("SELECT meta_value FROM {$remotedb->usermeta} WHERE user_id = ".$remote_vendor_id." AND meta_key= '".$meta_key."'");
  return $old_meta_value;
}
function save_remote_user_meta($remote_vendor_id, $meta_key, $meta_value){
global $remotedb;
  $old_meta_value = $remotedb->get_var("SELECT umeta_id FROM {$remotedb->usermeta} WHERE user_id = ".$remote_vendor_id." AND meta_key= '".$meta_key."'");
 if(empty($old_meta_value)){
  $remotedb->insert($remotedb->prefix."usermeta", array('meta_key' => $meta_key, 'meta_value' => $meta_value, 'user_id' => $remote_vendor_id));
 }else{
  $vendor_balance += $remote_line_subtotal;
  $remotedb->update($remotedb->prefix."usermeta", array( 'meta_value' => $meta_value), array('meta_key' => $meta_key, 'user_id' => $remote_vendor_id));
 }
}// function

if(!function_exists("remote_auto_image_id")){
    function remote_auto_image_id($image_url){
        global $remotedb;
        $attachment = $remotedb->get_col($remotedb->prepare("SELECT ID FROM {$remotedb->posts} WHERE guid='%s';", $image_url )); 
        
        return (isset($attachment[0]) && !empty($attachment[0]) ? $attachment[0] : "");
    }
}