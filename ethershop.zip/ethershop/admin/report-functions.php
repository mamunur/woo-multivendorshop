<?php
/**
 * Order Data
 *
 * Functions for displaying the order data meta box.
 *
 * @author    WooThemes
 * @category  Admin
 * @package   WooCommerce/Admin/Meta Boxes
 * @version     2.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

/**
 * WC_Meta_Box_Order_Data Class.
 */
function ethershop_get_total_sales_by_vendor($author_id, $start_date=NULL, $end_date=NULL) {
global $wpdb;
$query = "SELECT SUM( order_item_meta.meta_value )
  FROM {$wpdb->prefix}woocommerce_order_items as order_items
  LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta ON order_items.order_item_id = order_item_meta.order_item_id
  LEFT JOIN {$wpdb->posts} AS posts ON order_items.order_id = posts.ID
  WHERE posts.post_type    = 'shop_order'
  AND   order_items.order_item_type = 'line_item'
  AND   order_item_meta.meta_key = '_line_subtotal' 
  AND order_item_meta.order_item_id IN (SELECT {$wpdb->prefix}woocommerce_order_itemmeta.`order_item_id` as item_id FROM {$wpdb->posts}, {$wpdb->prefix}woocommerce_order_items, {$wpdb->prefix}woocommerce_order_itemmeta WHERE {$wpdb->posts}.post_status  IN ( 'wc-completed', 'wc-processing', 'wc-on-hold' ) AND {$wpdb->posts}.`ID` = {$wpdb->prefix}woocommerce_order_items.order_id AND {$wpdb->prefix}woocommerce_order_items.order_item_type = 'line_item' AND {$wpdb->prefix}woocommerce_order_items.order_item_id = {$wpdb->prefix}woocommerce_order_itemmeta.order_item_id AND {$wpdb->prefix}woocommerce_order_itemmeta.meta_key ='_product_id' AND {$wpdb->prefix}woocommerce_order_itemmeta.meta_value IN(Select ID from {$wpdb->posts} where {$wpdb->posts}.post_author =$author_id))";
$sale_totals = apply_filters( 'woocommerce_reports_sales_overview_order_totals', $wpdb->get_var( $query ) );
return $sale_totals;
 
}
function ethershop_get_total_items_by_vendor($author_id) {
global $wpdb;
$order_items = apply_filters( 'woocommerce_reports_sales_overview_order_items', absint( $wpdb->get_var( "
SELECT SUM( order_item_meta.meta_value )
  FROM {$wpdb->prefix}woocommerce_order_items as order_items
  LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta ON order_items.order_item_id = order_item_meta.order_item_id
  LEFT JOIN {$wpdb->posts} AS posts ON order_items.order_id = posts.ID
  WHERE posts.post_type    = 'shop_order'
  AND   order_items.order_item_type = 'line_item'
  AND   order_item_meta.meta_key = '_qty' 
  AND order_item_meta.order_item_id IN (SELECT {$wpdb->prefix}woocommerce_order_itemmeta.`order_item_id` as item_id FROM {$wpdb->posts}, {$wpdb->prefix}woocommerce_order_items, {$wpdb->prefix}woocommerce_order_itemmeta WHERE {$wpdb->posts}.post_status  IN ( 'wc-completed', 'wc-processing', 'wc-on-hold' ) AND {$wpdb->posts}.`ID` = {$wpdb->prefix}woocommerce_order_items.order_id AND {$wpdb->prefix}woocommerce_order_items.order_item_type = 'line_item' AND {$wpdb->prefix}woocommerce_order_items.order_item_id = {$wpdb->prefix}woocommerce_order_itemmeta.order_item_id AND {$wpdb->prefix}woocommerce_order_itemmeta.meta_key ='_product_id' AND {$wpdb->prefix}woocommerce_order_itemmeta.meta_value IN(Select ID from {$wpdb->posts} where {$wpdb->posts}.post_author = $author_id))
" ) ) );
return $order_items;
}

function ethershop_get_total_order_by_vendor($author_id) {
global $wpdb;
$order_items = apply_filters( 'woocommerce_reports_sales_overview_order_items', absint( $wpdb->get_var( "
SELECT count( order_items.order_id )
  FROM {$wpdb->prefix}woocommerce_order_items as order_items
  LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta ON order_items.order_item_id = order_item_meta.order_item_id
  LEFT JOIN {$wpdb->posts} AS posts ON order_items.order_id = posts.ID
  WHERE posts.post_type    = 'shop_order'
  AND order_items.order_item_type = 'line_item'
  AND order_item_meta.meta_key = '_product_id' 
  AND order_item_meta.order_item_id IN (SELECT {$wpdb->prefix}woocommerce_order_itemmeta.order_item_id as item_id FROM {$wpdb->posts}, {$wpdb->prefix}woocommerce_order_items, {$wpdb->prefix}woocommerce_order_itemmeta WHERE {$wpdb->posts}.post_status  IN ( 'wc-completed', 'wc-processing', 'wc-on-hold' ) AND {$wpdb->posts}.`ID` = {$wpdb->prefix}woocommerce_order_items.order_id AND {$wpdb->prefix}woocommerce_order_items.order_item_type = 'line_item' AND {$wpdb->prefix}woocommerce_order_items.order_item_id = {$wpdb->prefix}woocommerce_order_itemmeta.order_item_id AND {$wpdb->prefix}woocommerce_order_itemmeta.meta_key ='_product_id' AND {$wpdb->prefix}woocommerce_order_itemmeta.meta_value IN(Select ID from {$wpdb->posts} where {$wpdb->posts}.post_author = $author_id))
" ) ) );
return $order_items;
}

function ethershop_get_coupon_usage_by_vendor($author_id) {
global $wpdb;
$coupon_usage = apply_filters( 'woocommerce_reports_sales_overview_order_items', absint( $wpdb->get_var( "
SELECT SUM( order_item_meta.meta_value ) AS coupon_usage
  FROM {$wpdb->prefix}woocommerce_order_items as order_items
  LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta ON order_items.order_item_id = order_item_meta.order_item_id
  LEFT JOIN {$wpdb->posts} AS posts ON order_items.order_id = posts.ID
  WHERE posts.post_type    = 'shop_order'
  AND   order_items.order_item_type = 'coupon'
  AND   order_item_meta.meta_key = 'discount_amount'
  AND order_items.order_id IN (SELECT {$wpdb->prefix}woocommerce_order_items.`order_id` as order_id FROM {$wpdb->posts}, {$wpdb->prefix}woocommerce_order_items, {$wpdb->prefix}woocommerce_order_itemmeta WHERE {$wpdb->posts}.post_status  IN ( 'wc-completed', 'wc-processing', 'wc-on-hold' ) AND {$wpdb->posts}.`ID` = {$wpdb->prefix}woocommerce_order_items.order_id AND {$wpdb->prefix}woocommerce_order_items.order_item_type = 'line_item' AND {$wpdb->prefix}woocommerce_order_items.order_item_id = {$wpdb->prefix}woocommerce_order_itemmeta.order_item_id AND {$wpdb->prefix}woocommerce_order_itemmeta.meta_key ='_product_id'  AND {$wpdb->prefix}woocommerce_order_itemmeta.meta_value IN(Select ID from {$wpdb->posts} where {$wpdb->posts}.post_author =$author_id))
" ) ) );
return $coupon_usage;
}

function ethershop_get_total_shipping_by_vendor($author_id) {
global $wpdb;
$shipping_totals = apply_filters( 'woocommerce_reports_sales_overview_order_totals', absint( $wpdb->get_var( "
SELECT SUM( order_item_meta.meta_value )
  FROM {$wpdb->prefix}woocommerce_order_items as order_items
  LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta ON order_items.order_item_id = order_item_meta.order_item_id
  LEFT JOIN {$wpdb->posts} AS posts ON order_items.order_id = posts.ID
  WHERE posts.post_type    = 'shop_order'
  AND   order_items.order_item_type = 'shipping'
  AND   order_item_meta.meta_key = 'cost' 
  AND order_items.order_id IN (SELECT {$wpdb->prefix}woocommerce_order_items.`order_id` as order_id FROM {$wpdb->posts}, {$wpdb->prefix}woocommerce_order_items, {$wpdb->prefix}woocommerce_order_itemmeta WHERE {$wpdb->posts}.post_status  IN ( 'wc-completed', 'wc-processing', 'wc-on-hold' ) AND {$wpdb->posts}.`ID` = {$wpdb->prefix}woocommerce_order_items.order_id AND {$wpdb->prefix}woocommerce_order_items.order_item_type = 'line_item' AND {$wpdb->prefix}woocommerce_order_items.order_item_id = {$wpdb->prefix}woocommerce_order_itemmeta.order_item_id AND {$wpdb->prefix}woocommerce_order_itemmeta.meta_key ='_product_id'  AND {$wpdb->prefix}woocommerce_order_itemmeta.meta_value IN(Select ID from {$wpdb->posts} where {$wpdb->posts}.post_author =$author_id))
" ) ) );
return $shipping_totals;
 
}