<?php
/**
 * Order Data
 *
 * Functions for displaying the order data meta box.
 *
 * @author    WooThemes
 * @category  Admin
 * @package   WooCommerce/Admin/Meta Boxes
 * @version     2.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

/**
 * WC_Meta_Box_Order_Data Class.
 */
class WC_Shop_Order_Data {

  /**
   * Billing fields.
   *
   * @var array
   */
  protected static $billing_fields = array();

  /**
   * Shipping fields.
   *
   * @var array
   */
  protected static $shipping_fields = array();

  /**
   * Init billing and shipping fields we display + save.
   */
  public static function init_address_fields() {

    self::$billing_fields = apply_filters( 'woocommerce_admin_billing_fields', array(
      'first_name' => array(
        'label' => __( 'First name', 'woocommerce' ),
        'show'  => false,
      ),
      'last_name' => array(
        'label' => __( 'Last name', 'woocommerce' ),
        'show'  => false,
      ),
      'company' => array(
        'label' => __( 'Company', 'woocommerce' ),
        'show'  => false,
      ),
      'address_1' => array(
        'label' => __( 'Address line 1', 'woocommerce' ),
        'show'  => false,
      ),
      'address_2' => array(
        'label' => __( 'Address line 2', 'woocommerce' ),
        'show'  => false,
      ),
      'city' => array(
        'label' => __( 'City', 'woocommerce' ),
        'show'  => false,
      ),
      'postcode' => array(
        'label' => __( 'Postcode / ZIP', 'woocommerce' ),
        'show'  => false,
      ),
      'country' => array(
        'label'   => __( 'Country', 'woocommerce' ),
        'show'    => false,
        'class'   => 'js_field-country select short',
        'type'    => 'select',
        'options' => array( '' => __( 'Select a country&hellip;', 'woocommerce' ) ) + WC()->countries->get_allowed_countries(),
      ),
      'state' => array(
        'label' => __( 'State / County', 'woocommerce' ),
        'class'   => 'js_field-state select short',
        'show'  => false,
      ),
      'email' => array(
        'label' => __( 'Email address', 'woocommerce' ),
      ),
      'phone' => array(
        'label' => __( 'Phone', 'woocommerce' ),
      ),
    ) );

    self::$shipping_fields = apply_filters( 'woocommerce_admin_shipping_fields', array(
      'first_name' => array(
        'label' => __( 'First name', 'woocommerce' ),
        'show'  => false,
      ),
      'last_name' => array(
        'label' => __( 'Last name', 'woocommerce' ),
        'show'  => false,
      ),
      'company' => array(
        'label' => __( 'Company', 'woocommerce' ),
        'show'  => false,
      ),
      'address_1' => array(
        'label' => __( 'Address line 1', 'woocommerce' ),
        'show'  => false,
      ),
      'address_2' => array(
        'label' => __( 'Address line 2', 'woocommerce' ),
        'show'  => false,
      ),
      'city' => array(
        'label' => __( 'City', 'woocommerce' ),
        'show'  => false,
      ),
      'postcode' => array(
        'label' => __( 'Postcode / ZIP', 'woocommerce' ),
        'show'  => false,
      ),
      'country' => array(
        'label'   => __( 'Country', 'woocommerce' ),
        'show'    => false,
        'type'    => 'select',
        'class'   => 'js_field-country select short',
        'options' => array( '' => __( 'Select a country&hellip;', 'woocommerce' ) ) + WC()->countries->get_shipping_countries(),
      ),
      'state' => array(
        'label' => __( 'State / County', 'woocommerce' ),
        'class'   => 'js_field-state select short',
        'show'  => false,
      ),
    ) );
  }

  /**
   * Output the metabox.
   *
   * @param WP_Post $post
   */
  public static function output( $post_id ) {
    global $theorder;
    if ( ! is_object( $theorder ) ) {
      $theorder = wc_get_order( $post_id );
    }

    $order = $theorder;
    //echo "<pre>".print_r($order, 1)."</pre>";
     self::init_address_fields();

    if ( WC()->payment_gateways() ) {
      $payment_gateways = WC()->payment_gateways->payment_gateways();
    } else {
      $payment_gateways = array();
    }
    $payment_method = $order->get_payment_method();

    $order_type_object = get_post_type_object( 'shop_order' );
    wp_nonce_field( 'woocommerce_save_data', 'woocommerce_meta_nonce' );
    ?>
      <hr class="wp-header-end">
<form id="vendor_order" method="post" name="vendor_order" action="<?php echo $_SERVER['REQUEST_URI'] ?>">
      <div id="poststuff">
<div id="post-body" class="metabox-holder columns-2" >
<div id="postbox-container-1" class="postbox-container">
        <?php self::sideoutput($post_id); ?>
</div>
<div id="postbox-container-2" class="postbox-container">
<div id="normal-sortables" class="meta-box-sortables ui-sortable">
<div id="woocommerce-order-data" class="postbox ">
    <div class="inside">
      <div class="panel-wrap woocommerce">
      <input name="post_title" type="hidden" value="<?php echo empty( $post->post_title ) ? __( 'Order', 'woocommerce' ) : esc_attr( $post->post_title ); ?>" />
      <input name="post_status" type="hidden" value="<?php echo esc_attr( $post->post_status ); ?>" />
      <div id="order_data" class="panel">

        <h2><?php
          /* translators: 1: order type 2: order number */
          printf(
            esc_html__( '%1$s #%2$s details', 'woocommerce' ),
            $order_type_object->labels->singular_name,
            $order->get_order_number()
          );
        ?></h2>
        <p class="order_number"><?php

          if ( $payment_method ) {
            /* translators: %s: payment method */
            printf(
              __( 'Payment via %s', 'woocommerce' ),
              ( isset( $payment_gateways[ $payment_method ] ) ? esc_html( $payment_gateways[ $payment_method ]->get_title() ) : esc_html( $payment_method ) )
            );

            if ( $transaction_id = $order->get_transaction_id() ) {
                if ( isset( $payment_gateways[ $payment_method ] ) && ( $url = $payment_gateways[ $payment_method ]->get_transaction_url( $order ) ) ) {
                echo ' (<a href="' . esc_url( $url ) . '" target="_blank">' . esc_html( $transaction_id ) . '</a>)';
              } else {
                echo ' (' . esc_html( $transaction_id ) . ')';
              }
            }

            if ( $order->get_date_paid() ) {
              /* translators: 1: date 2: time */
              printf( ' ' . __( 'on %1$s @ %2$s', 'woocommerce' ), wc_format_datetime( $order->get_date_paid() ), wc_format_datetime( $order->get_date_paid(), get_option( 'time_format' ) ) );
            }

            echo '. ';
          }

          if ( $ip_address = $order->get_customer_ip_address() ) {
            /* translators: %s: IP address */
            printf(
              __( 'Customer IP: %s', 'woocommerce' ),
              '<span class="woocommerce-Order-customerIP">' . esc_html( $ip_address ) . '</span>'
            );
          }
        ?></p>
        <div class="order_data_column_container">
          <div class="order_data_column">
            <h3><?php _e( 'General Details', 'woocommerce' ); ?></h3>

            <p class="form-field form-field-wide"><label for="order_date"><?php _e( 'Order date:', 'woocommerce' ) ?></label>
              <input type="text" class="date-picker" name="order_date" id="order_date" maxlength="10" value="<?php echo date_i18n( 'Y-m-d', strtotime( $post->post_date ) ); ?>" pattern="<?php echo esc_attr( apply_filters( 'woocommerce_date_input_html_pattern', '[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])' ) ); ?>" />@&lrm;<input type="number" class="hour" placeholder="<?php esc_attr_e( 'h', 'woocommerce' ) ?>" name="order_date_hour" id="order_date_hour" min="0" max="23" step="1" value="<?php echo date_i18n( 'H', strtotime( $post->post_date ) ); ?>" pattern="([01]?[0-9]{1}|2[0-3]{1})" />:<input type="number" class="minute" placeholder="<?php esc_attr_e( 'm', 'woocommerce' ) ?>" name="order_date_minute" id="order_date_minute" min="0" max="59" step="1" value="<?php echo date_i18n( 'i', strtotime( $post->post_date ) ); ?>" pattern="[0-5]{1}[0-9]{1}" />&lrm;
            </p>

            <p class="form-field form-field-wide wc-order-status"><label for="order_status"><?php _e( 'Order status:', 'woocommerce' ) ?> <?php
              if ( $order->needs_payment() ) {
                printf( '<a href="%s">%s</a>',
                  esc_url( $order->get_checkout_payment_url() ),
                  __( 'Customer payment page &rarr;', 'woocommerce' )
                );
              }
            ?></label>
<?php $vendor_order_status = self::vendor_order_status_value( $post_id );  ?>
            <input type="text" id="order_status" name="order_status"  value="<?php echo $vendor_order_status; ?>"class="wc-enhanced-select">
              </p>           
          </div><!--order_data_column-->
          <div class="order_data_column">
            <h3>
              <?php _e( 'Billing details', 'woocommerce' ); ?>
            </h3>
            <?php
              // Display values
              echo '<div class="address">';

                if ( $order->get_formatted_billing_address() ) {
                  echo '<p><strong>' . __( 'Address:', 'woocommerce' ) . '</strong>' . wp_kses( $order->get_formatted_billing_address(), array( 'br' => array() ) ) . '</p>';
                } else {
                  echo '<p class="none_set"><strong>' . __( 'Address:', 'woocommerce' ) . '</strong> ' . __( 'No billing address set.', 'woocommerce' ) . '</p>';
                }

                foreach ( self::$billing_fields as $key => $field ) {
                  if ( isset( $field['show'] ) && false === $field['show'] ) {
                    continue;
                  }

                  $field_name = 'billing_' . $key;

                  if ( is_callable( array( $order, 'get_' . $field_name ) ) ) {
                    $field_value = $order->{"get_$field_name"}( 'edit' );
                  } else {
                    $field_value = $order->get_meta( '_' . $field_name );
                  }

                  if ( 'billing_phone' === $field_name ) {
                    $field_value = wc_make_phone_clickable( $field_value );
                  } else {
                    $field_value = make_clickable( esc_html( $field_value ) );
                  }

                  echo '<p><strong>' . esc_html( $field['label'] ) . ':</strong> ' . wp_kses_post( $field_value ) . '</p>';
                }

              echo '</div>';
            ?>
          </div><!--order_data_column-->
          <div class="order_data_column">
            <h3>
              <?php _e( 'Shipping details', 'woocommerce' ); ?>
            </h3>
            <?php
              // Display values
              echo '<div class="address">';

                if ( $order->get_formatted_shipping_address() ) {
                  echo '<p><strong>' . __( 'Address:', 'woocommerce' ) . '</strong>' . wp_kses( $order->get_formatted_shipping_address(), array( 'br' => array() ) ) . '</p>';
                } else {
                  echo '<p class="none_set"><strong>' . __( 'Address:', 'woocommerce' ) . '</strong> ' . __( 'No shipping address set.', 'woocommerce' ) . '</p>';
                }

                if ( ! empty( self::$shipping_fields ) ) {
                  foreach ( self::$shipping_fields as $key => $field ) {
                    if ( isset( $field['show'] ) && false === $field['show'] ) {
                      continue;
                    }

                    $field_name = 'shipping_' . $key;

                    if ( is_callable( array( $order, 'get_' . $field_name ) ) ) {
                      $field_value = $order->{"get_$field_name"}( 'edit' );
                    } else {
                      $field_value = $order->get_meta( '_' . $field_name );
                    }

                    echo '<p><strong>' . esc_html( $field['label'] ) . ':</strong> ' . make_clickable( esc_html( $field_value ) ) . '</p>';
                  }
                }

                if ( apply_filters( 'woocommerce_enable_order_notes_field', 'yes' == get_option( 'woocommerce_enable_order_comments', 'yes' ) ) && $post->post_excerpt ) {
                  echo '<p><strong>' . __( 'Customer provided note:', 'woocommerce' ) . '</strong> ' . nl2br( esc_html( $post->post_excerpt ) ) . '</p>';
                }

              echo '</div>';

              // Display form
              echo '<div class="edit_address">';

              if ( apply_filters( 'woocommerce_enable_order_notes_field', 'yes' == get_option( 'woocommerce_enable_order_comments', 'yes' ) ) ) {
                ?>
                <p class="form-field form-field-wide"><label for="excerpt"><?php _e( 'Customer provided note', 'woocommerce' ) ?>:</label>
                <textarea rows="1" cols="40" name="excerpt" tabindex="6" id="excerpt" placeholder="<?php esc_attr_e( 'Customer notes about the order', 'woocommerce' ); ?>"><?php echo wp_kses_post( $post->post_excerpt ); ?></textarea></p>
                <?php
              }

              echo '</div>';
            ?>
          </div><!--order_data_column-->
        </div><!--order_data_column_container-->
        <div class="clear"></div>
</div><!--panel-->
        </div><!--panel-wrap-->
      </div><!--inside-->
      </div><!--class="postbox "-->
      <div id="woocommerce-order-items" class="postbox">
        <?php self::itemoutput($order); ?>
      </div><!--id="woocommerce-order-items" class="postbox"-->
  </div><!--class="meta-box-sortables ui-sortable"--> 
  </div> <!--id="postbox-container-2"-->
  </div><!--id="post-body"-->
  <br class="clear">
  </div><!--poststuff-->
</form>

    <?php
  }// function close
public static function vendor_order_status_value( $post_id ) {
global $wpdb, $current_user;
$user_id = $current_user->ID;

$orderitem = $wpdb->get_results("SELECT * FROM ".$wpdb->prefix."woocommerce_order_items WHERE order_id = $post_id", ARRAY_A);
 foreach($orderitem as $value):
  $item_meta = $wpdb->get_row("SELECT meta_key , meta_value FROM ".$wpdb->prefix."woocommerce_order_itemmeta WHERE meta_key = '_product_id' AND order_item_id =". $value['order_item_id'], ARRAY_A);
	  $_product_id = $item_meta['meta_value'];
	  $vendor_id = get_post_field( 'post_author', $_product_id );
	if($vendor_id == $user_id){
	 $vendor_order_status = $wpdb->get_var("SELECT meta_value FROM ".$wpdb->prefix."woocommerce_order_itemmeta WHERE meta_key = 'vendor_order_status' AND order_item_id =". $value['order_item_id']);
	}
 endforeach;
 return $vendor_order_status;
}
public static function sideoutput( $post_id ) {
$vendor_order_status = self::vendor_order_status_value( $post_id );
    $order_actions = apply_filters( 'woocommerce_order_actions', array(
      'mark_shipped'              => __( 'Mark As Shipped', 'woocommerce' ),
    ) );
    ?>
<div id="side-sortables" class="meta-box-sortables ui-sortable">
  <div id="woocommerce-order-actions" class="postbox">
    <button class="handlediv" type="button" area-expanded="true">
      <span class="screen-reader-text">Toggle Panel:Order Actions</span><span class="toggle-indicator" area-hidden="true"></span>
    </button>
    <h2 class="hndle ui-sortable-handle"><span>Order actions</span></h2>
    <div class="inside">
    <ul class="order_actions submitbox">
	
<?php 
if($vendor_order_status == "Shipped"){
  echo '<li class="wide"> Shipped </li>';
}else{ 
?>
      <li class="wide" id="actions">
        <select name="wc_order_action">
          <option value=""><?php _e( 'Choose an action...', 'woocommerce' ); ?></option>
          <?php foreach ( $order_actions as $action => $title ) { ?>
            <option value="<?php echo $action; ?>"><?php echo $title; ?></option>
          <?php } ?>
        </select>
		<input type="hidden" name="order_id" value="<?php echo $post_id; ?>" />
      </li>

      <li class="wide">
        <input type="submit" class="button save_vendor_order button-primary " name="save_vendor_order_action" value="<?php echo esc_attr__( 'Update', 'woocommerce' ); ?>" />
      </li>
<?php } ?>
    </ul>
   </div><!--class="inside"-->
   </div><!--id="woocommerce-order-actions"-->
   <div id="woocommerce-order-notes" class="postbox">
     <button class="handlediv" type="button" area-expanded="true">
      <span class="screen-reader-text">Toggle Panel:Order Notes</span><span class="toggle-indicator" area-hidden="true"></span>
    </button>
    <h2 class="hndle ui-sortable-handle"><span>Order notes</span></h2>
    <div class="inside">
    <?php
      $args = array(
      'order_id' => $post_id,
    );

    $notes = wc_get_order_notes( $args );

    echo '<ul class="order_notes">';

    if ( $notes ) {

      foreach ( $notes as $note ) {

        $note_classes   = array( 'note' );
        $note_classes[] = $note->customer_note ? 'customer-note' : '';
        $note_classes[] = 'system' === $note->added_by ? 'system-note' : '';
        $note_classes   = apply_filters( 'woocommerce_order_note_class', array_filter( $note_classes ), $note );
        ?>
        <li rel="<?php echo absint( $note->id ); ?>" class="<?php echo esc_attr( implode( ' ', $note_classes ) ); ?>">
          <div class="note_content">
            <?php echo wpautop( wptexturize( wp_kses_post( $note->content ) ) ); ?>
          </div>
          <p class="meta">
            <abbr class="exact-date" title="<?php echo $note->date_created->date( 'y-m-d h:i:s' ); ?>"><?php printf( __( 'added on %1$s at %2$s', 'woocommerce' ), $note->date_created->date_i18n( wc_date_format() ), $note->date_created->date_i18n( wc_time_format() ) ); ?></abbr>
            <?php
            if ( 'system' !== $note->added_by ) :
              /* translators: %s: note author */
              printf( ' ' . __( 'by %s', 'woocommerce' ), $note->added_by );
            endif;
            ?>
            <a href="#" class="delete_note" role="button"><?php _e( 'Delete note', 'woocommerce' ); ?></a>
          </p>
        </li>
        <?php
      }
    } else {
      echo '<li>' . __( 'There are no notes yet.', 'woocommerce' ) . '</li>';
    }

    echo '</ul>';
    ?>
    <div class="add_note">
      <p>
        <label for="add_order_note"><?php _e( 'Add note', 'woocommerce' ); ?> <?php echo wc_help_tip( __( 'Add a note for your reference, or add a customer note (the user will be notified).', 'woocommerce' ) ); ?></label>
        <textarea type="text" name="order_note" id="add_order_note" class="input-text" cols="20" rows="5"></textarea>
      </p>
      <p>
        <label for="order_note_type" class="screen-reader-text"><?php _e( 'Note type', 'woocommerce' ); ?></label>
        <select name="order_note_type" id="order_note_type">
          <option value=""><?php _e( 'Private note', 'woocommerce' ); ?></option>
          <option value="customer"><?php _e( 'Note to customer', 'woocommerce' ); ?></option>
        </select>
        <button type="button" class="add_note button"><?php _e( 'Add', 'woocommerce' ); ?></button>
      </p>
    </div>
    </div><!--inside-->
   </div><!--id="woocommerce-order-notes"-->
  </div> <!--class="meta-box-sortables ui-sortable"-->
    <?php
  }

public static function itemoutput($order){ 
global $current_user;
$user_id = $current_user->ID;
?>
<div class="inside">
 <div class="woocommerce_order_items_wrapper wc-order-items-editable">
  <table class="woocommerce_order_items" cellpadding="0" cellspacing="0" >
   <thead><tr><th class="item sortable" colspan="2" data-sort="string-ins">Item</th>
	<th class="item_cost sortable" data-sort="float">Cost</th>
	<th class="quantity sortable" data-sort="int">Qty</th>
	<th class="line_cost sortable" data-sort="float">Total</th>
	<th class="wc-order-edit-line-item" width="1%"></th></tr>    
   </thead>
<?php 
 foreach ($order->get_items() as $item_id => $item) {
    // Get an instance of corresponding the WC_Product object
    $product = $item->get_product();
	$product_id = $item->get_product_id();
	$vendor_id = get_post_field( 'post_author', $product_id );
	//echo "<pre>".print_r($product,1)."</pre>";
  if($vendor_id == $user_id):
    $product_name = $product->get_name(); // Get the product name

    $item_quantity = $item->get_quantity(); // Get the item quantity

    $item_total = $item->get_total(); // Get the item line total
    $product_link = $product ? admin_url( 'post.php?post=' . $item->get_product_id() . '&action=edit' ) : '';
    $thumbnail    = $product ? apply_filters( 'woocommerce_admin_order_item_thumbnail', $product->get_image( 'thumbnail', array( 'title' => '' ), false ), $item_id, $item ) : '';
    ?>
<tr class="item <?php echo apply_filters( 'woocommerce_admin_html_order_item_class', ( ! empty( $class ) ? $class : '' ), $item, $order ); ?>" data-order_item_id="<?php echo esc_attr( $item_id ); ?>">
  <td class="thumb">
    <?php echo '<div class="wc-order-item-thumbnail">' . wp_kses_post( $thumbnail ) . '</div>'; ?>
  </td>
  <td class="name" data-sort-value="<?php echo esc_attr( $item->get_name() ); ?>">
    <?php
      echo $product_link ? '<a href="' . esc_url( $product_link ) . '" class="wc-order-item-name">' . esc_html( $item->get_name() ) . '</a>' : '<div class="wc-order-item-name">' . esc_html( $item->get_name() ) . '</div>';

      if ( $product && $product->get_sku() ) {
        echo '<div class="wc-order-item-sku"><strong>' . __( 'SKU:', 'woocommerce' ) . '</strong> ' . esc_html( $product->get_sku() ) . '</div>';
      }

      if ( $item->get_variation_id() ) {
        echo '<div class="wc-order-item-variation"><strong>' . __( 'Variation ID:', 'woocommerce' ) . '</strong> ';
        if ( 'product_variation' === get_post_type( $item->get_variation_id() ) ) {
          echo esc_html( $item->get_variation_id() );
        } else {
          /* translators: %s: variation id */
          printf( esc_html__( '%s (No longer exists)', 'woocommerce' ), $item->get_variation_id() );
        }
        echo '</div>';
      }
    ?>
  </td>
  <td class="item_cost" width="1%" data-sort-value="<?php echo esc_attr( $order->get_item_subtotal( $item, false, true ) ); ?>">
    <div class="view">
      <?php
        echo wc_price( $order->get_item_total( $item, false, true ), array( 'currency' => $order->get_currency() ) );

        if ( $item->get_subtotal() !== $item->get_total() ) {
          echo '<span class="wc-order-item-discount">-' . wc_price( wc_format_decimal( $order->get_item_subtotal( $item, false, false ) - $order->get_item_total( $item, false, false ), '' ), array( 'currency' => $order->get_currency() ) ) . '</span>';
        }
      ?>
    </div>
  </td>
  <td class="quantity" width="1%">
    <div class="view">
      <?php
        echo '<small class="times">&times;</small> ' . esc_html( $item->get_quantity() );

        if ( $refunded_qty = $order->get_qty_refunded_for_item( $item_id ) ) {
          echo '<small class="refunded">' . ( $refunded_qty * -1 ) . '</small>';
        }
      ?>
    </div>
  </td>
  <td class="line_cost" width="1%" data-sort-value="<?php echo esc_attr( $item->get_total() ); ?>">
    <div class="view">
      <?php
        echo wc_price( $item->get_total(), array( 'currency' => $order->get_currency() ) );

        if ( $item->get_subtotal() !== $item->get_total() ) {
          echo '<span class="wc-order-item-discount">-' . wc_price( wc_format_decimal( $item->get_subtotal() - $item->get_total(), '' ), array( 'currency' => $order->get_currency() ) ) . '</span>';
        }

        if ( $refunded = $order->get_total_refunded_for_item( $item_id ) ) {
          echo '<small class="refunded">' . wc_price( $refunded, array( 'currency' => $order->get_currency() ) ) . '</small>';
        }
      ?>
    </div>
  </td>
  <td class="wc-order-edit-line-item" width="1%">
    <div class="wc-order-edit-line-item-actions">
    </div>
  </td>
</tr>
  <?php
 endif;
}
              ?>
            </table>
          </div>
        </div><!--inside-->
        <?php
}
  /**
   * Save meta box data.
   *
   * @param int $order_id Order ID.
   */
  public static function save( $order_id ) {
    self::init_address_fields();

    // Ensure gateways are loaded in case they need to insert data into the emails.
    WC()->payment_gateways();
    WC()->shipping();

    // Get order object.
    $order = wc_get_order( $order_id );
    $props = array();

    // Create order key.
    if ( ! $order->get_order_key() ) {
      $props['order_key'] = 'wc_' . apply_filters( 'woocommerce_generate_order_key', uniqid( 'order_' ) );
    }

    // Update customer.
    $customer_id = isset( $_POST['customer_user'] ) ? absint( $_POST['customer_user'] ) : 0;
    if ( $customer_id !== $order->get_customer_id() ) {
      $props['customer_id'] = $customer_id;
    }

    // Update billing fields.
    if ( ! empty( self::$billing_fields ) ) {
      foreach ( self::$billing_fields as $key => $field ) {
        if ( ! isset( $field['id'] ) ) {
          $field['id'] = '_billing_' . $key;
        }

        if ( ! isset( $_POST[ $field['id'] ] ) ) {
          continue;
        }

        if ( is_callable( array( $order, 'set_billing_' . $key ) ) ) {
          $props[ 'billing_' . $key ] = wc_clean( $_POST[ $field['id'] ] );
        } else {
          $order->update_meta_data( $field['id'], wc_clean( $_POST[ $field['id'] ] ) );
        }
      }
    }

    // Update shipping fields.
    if ( ! empty( self::$shipping_fields ) ) {
      foreach ( self::$shipping_fields as $key => $field ) {
        if ( ! isset( $field['id'] ) ) {
          $field['id'] = '_shipping_' . $key;
        }

        if ( ! isset( $_POST[ $field['id'] ] ) ) {
          continue;
        }

        if ( is_callable( array( $order, 'set_shipping_' . $key ) ) ) {
          $props[ 'shipping_' . $key ] = wc_clean( $_POST[ $field['id'] ] );
        } else {
          $order->update_meta_data( $field['id'], wc_clean( $_POST[ $field['id'] ] ) );
        }
      }
    }

    if ( isset( $_POST['_transaction_id'] ) ) {
      $props['transaction_id'] = wc_clean( $_POST['_transaction_id'] );
    }

    // Payment method handling.
    if ( $order->get_payment_method() !== wp_unslash( $_POST['_payment_method'] ) ) {
      $methods              = WC()->payment_gateways->payment_gateways();
      $payment_method       = wc_clean( $_POST['_payment_method'] );
      $payment_method_title = $payment_method;

      if ( isset( $methods ) && isset( $methods[ $payment_method ] ) ) {
        $payment_method_title = $methods[ $payment_method ]->get_title();
      }

      $props['payment_method'] = $payment_method;
      $props['payment_method_title'] = $payment_method_title;
    }

    // Update date.
    if ( empty( $_POST['order_date'] ) ) {
      $date = current_time( 'timestamp', true );
    } else {
      $date = gmdate( 'Y-m-d H:i:s', strtotime( $_POST['order_date'] . ' ' . (int) $_POST['order_date_hour'] . ':' . (int) $_POST['order_date_minute'] . ':00' ) );
    }

    $props['date_created'] = $date;

    // Save order data.
    $order->set_props( $props );
    $order->set_status( wc_clean( $_POST['order_status'] ), '', true );
    $order->save();
  }
}
