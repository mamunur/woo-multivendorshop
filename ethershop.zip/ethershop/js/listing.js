(function($) {
  "use strict";
jQuery.noConflict();
jQuery(document).ready(function($){
   

    $('input[name="user_type"]:radio').on('change', function(e) {
	   e.preventDefault();
	   var user_type = $('input[name="user_type"]:checked').val();
	   //alert(user_type); 
	   if(user_type == 'c'){
		   $( ".vendor-display" ).slideUp();
	   }else if(user_type == 'v'){
		   $( ".vendor-display" ).slideDown();
	   }
	});



}); //close main document

})(jQuery);

