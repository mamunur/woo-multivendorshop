(function($) {
  "use strict";
jQuery.noConflict();
jQuery(document).ready(function($){
    $('.save_vendor_order').on('click', function(e) {
	   e.preventDefault();
	   var wc_order_action = $('select[name="wc_order_action"] :selected').val();
	   var order_id = $('input[name="order_id"]').val();
	   var value = $(this).val();
	   //alert(value);
	   if(wc_order_action == ''){
	     //alert("Please select an action");
	     return;
	   }
	    $.ajax({
		 type: "post",
		 url: ajax_object.ajaxurl,
		 data: { action: "save_vendor_order_action", wc_order_action:wc_order_action, order_id:order_id },
		  success: function(response) { 
		   //$('.av_seat').html(response.data);
			 //alert(response);
			 if(response == 'success'){
			  $('input[name="order_status"]').val('Shipped');
			  $('input[name="save_vendor_order_action"]').attr("disabled", true);
			 }
		  }
	    });
	});
var file_frame_banner;
$(document).on("click", "#store_banner", function(e){
	e.preventDefault();
	//alert("OK");
	if ( file_frame_banner ) {
	 file_frame_banner.open();
	 return;
	}
	    // Create the media frame.
	    file_frame_banner = wp.media.frames.file_frame_banner = wp.media({
	      	title: jQuery( this ).data( 'uploader-title' ),
	      	button: {
	        	text: jQuery( this ).data( 'uploader-button-text' ),
	      	},
	      	multiple: false,
	    	library : { type : 'image'},
	    });

	    // highlight selected image
	    file_frame_banner.on('open', function(){
	    	var selection = file_frame_banner.state().get('selection');

	    	var attachement = wp.media.attachment($(".store_banner_input").data("id"));
	    	//attachement.fetch();
	    	selection.add( attachement ? [ attachement ] : [] );
	    });
	 
	    // Finally, open the modal
	    file_frame_banner.open();	    

		file_frame_banner.on( 'select', function() {	 
	    	var selection = file_frame_banner.state().get('selection');
	 
	    	selection.map( function( attachment ) {	 
	      		attachment = attachment.toJSON();	 			
	 			$(".store_banner_input").val(attachment.id);
	 			$(".store_banner_input").data("id", attachment.id);
				$(".remote_store_banner_input").val(attachment.url);
	 			$(".remote_store_banner_input").data("id", attachment.url);
	 			if($(".store_banner_area img").length){
	 				$(".store_banner_area img").attr("src", attachment.url);
		    	} else {
		    		$(".store_banner_area").append("<img src='" + attachment.url + "' style='width:100%;margin-top:8px;'>");
		    	}
		    });

		});
		
  });
var file_frame_profile;
 $(document).on("click", "#profile_picture", function(e){
	e.preventDefault();
	// If the media frame already exists, reopen it.
	
	//alert("OK");
	if ( file_frame_profile ) {
	      file_frame_profile.open();
	      return;
	    }
	 
	    // Create the media frame.
	    file_frame_profile = wp.media.frames.file_frame_profile = wp.media({
	      	title: jQuery( this ).data( 'uploader-title' ),
	      	button: {
	        	text: jQuery( this ).data( 'uploader-button-text' ),
	      	},
	      	multiple: false,
	    	library : { type : 'image'},
	    });

	    // highlight selected image
	    file_frame_profile.on('open', function(){
	    	var selection = file_frame_profile.state().get('selection');

	    	var attachement = wp.media.attachment($(".profile_picture_input").data("id"));
	    	//attachement.fetch();
	    	selection.add( attachement ? [ attachement ] : [] );
	    });
	 
	    // Finally, open the modal
	    file_frame_profile.open();	    

		file_frame_profile.on( 'select', function() {	 
	    	var selection = file_frame_profile.state().get('selection');
	 
	    	selection.map( function( attachment ) {	 
	      		attachment = attachment.toJSON();	 			
	 			$(".profile_picture_input").val(attachment.id);
	 			$(".profile_picture_input").data("id", attachment.id);
$(".remote_profile_picture_input").val(attachment.url);
$(".remote_profile_picture_input").data("id", attachment.url);
	 			if($(".profile_picture_area img").length){
	 				$(".profile_picture_area img").attr("src", attachment.url);
		    	} else {
		    		$(".profile_picture_area").append("<img src='" + attachment.url + "' style='width:100%;margin-top:8px;'>");
		    	}
		    });

		});
		
  });
 $(document).on("change", ".vendor input[name='vendor-switch']", function(e){
	var user_id = $(this).attr('id');																	  
	if ($(this).is(':checked')) {
		var vendor_switch = 1;
    }else{
 		var vendor_switch = 2;
	}
	//alert(vendor_switch);
jQuery.ajax({
  url: ajax_object.ajaxurl,
  type: 'POST',
  data: { action: 'switch_vendor_status', vendor_switch:vendor_switch, user_id:user_id},
  success:function(response){
   alert(response);
  }
});

 });											 
}); //close main document

})(jQuery);